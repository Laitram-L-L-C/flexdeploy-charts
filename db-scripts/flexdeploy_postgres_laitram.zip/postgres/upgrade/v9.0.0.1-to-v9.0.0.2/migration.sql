insert into FD.FD_FLEXDEPLOY_VERSION values('9.0.0.2',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

-- 9.0.2 - for rollback request speed (postgres only) - begin 
CREATE INDEX PROJECT_OBJECT_ATTRIBUTEX2 ON FD.PROJECT_OBJECT_ATTRIBUTE (PROJECT_OBJECT_ID, OBJECT_ATTR_DEF_ID) WHERE ATTRIBUTE_VALUE_SMALL = 'SCM';
-- 9.0.2 - for rollback request speed (postgres only) - end 

--leave at the end
commit;