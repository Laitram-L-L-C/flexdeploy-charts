-- 7.0.0.2
insert into FD.FD_FLEXDEPLOY_VERSION values('7.0.0.2',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

UPDATE FD.PIPELINE_STAGE_STEP_EXEC_WFRQ SET SUBMIT_STATUS='NOT_ATTEMPTED' WHERE SUBMIT_STATUS='PENDING';

-- leave at the end
commit;
