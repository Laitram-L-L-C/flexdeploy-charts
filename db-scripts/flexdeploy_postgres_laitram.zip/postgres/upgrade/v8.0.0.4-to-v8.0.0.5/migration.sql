insert into FD.FD_FLEXDEPLOY_VERSION values('8.0.0.5',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

ALTER TABLE FD.PROJECT_OBJECT ALTER COLUMN SEQUENCE_NUMBER TYPE NUMERIC(8, 0);

-- leave at the end
commit;