insert into FD.FD_FLEXDEPLOY_VERSION values('9.0.0.3',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

UPDATE fd.property_key_definition
SET
    property_key_sub_datatype = 'TextField'
WHERE
    property_key_sub_datatype = '' 
    AND property_key_datatype = 'String';

UPDATE fd.property_key_definition
SET
    property_key_sub_datatype = 'Long'
WHERE
    property_key_sub_datatype = '' 
    AND property_key_datatype = 'Integer';

UPDATE fd.property_key_definition
SET
    property_key_sub_datatype = 'Boolean'
WHERE
    property_key_sub_datatype = '' 
    AND property_key_datatype = 'Boolean';

UPDATE fd.property_key_definition
SET
    property_key_sub_datatype = 'Double'
WHERE
    property_key_sub_datatype = '' 
    AND property_key_datatype = 'Double';

UPDATE fd.property_key_definition
SET
    property_key_sub_datatype = 'Directory'
WHERE
    property_key_sub_datatype = 'DIRECTORY';
    
UPDATE fd.property_key_definition
SET
    property_key_sub_datatype = 'Long'
WHERE
    property_key_sub_datatype = '' 
    AND property_key_datatype = 'Long';

-- password history/reset - start

CREATE TABLE FD.FD_PASSWORD_HISTORY 
(
  USER_ID NUMERIC(20, 0) NOT NULL 
, PASSWORD VARCHAR(255) NOT NULL 
, CREATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP NOT NULL 
, CREATED_BY VARCHAR(128) NOT NULL
);

ALTER TABLE FD.FD_PASSWORD_HISTORY
ADD CONSTRAINT FD_PASSWORD_HISTORY_FK1 FOREIGN KEY
(
  USER_ID 
)
REFERENCES FD.FD_USER
(
  USER_ID 
);

CREATE INDEX FD_PASSWORD_HISTORY_INDEX1 ON FD.FD_PASSWORD_HISTORY (USER_ID);

grant all privileges on FD.FD_PASSWORD_HISTORY to FD_ADMIN;

alter table FD.FD_USER add PASSWORD_UPDATED_ON TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL;

CREATE TABLE FD.FD_USER_PASSWORD_RESET_TOKEN 
(
  RESET_TOKEN_ID NUMERIC(20, 0) NOT NULL
, USER_ID NUMERIC(20, 0) NOT NULL 
, RESET_TOKEN_HASH VARCHAR(1000) NOT NULL 
, RESET_TOKEN_EXPIRY TIMESTAMP WITH TIME ZONE NOT NULL
, CREATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP NOT NULL 
, CREATED_BY VARCHAR(128) NOT NULL
, CONSTRAINT FD_USER_PASSWORD_RESET_TOK_PK PRIMARY KEY 
  (
    RESET_TOKEN_ID 
  )
);

ALTER TABLE FD.FD_USER_PASSWORD_RESET_TOKEN
ADD CONSTRAINT FD_USER_PASSWORD_RESET_TOKEN_FK1 FOREIGN KEY
(
  USER_ID 
)
REFERENCES FD.FD_USER
(
  USER_ID 
);

ALTER TABLE FD.FD_USER_PASSWORD_RESET_TOKEN
ADD CONSTRAINT FD_USER_PASSWORD_RESET_TO_UK1 UNIQUE 
(
  RESET_TOKEN_HASH 
)
;

grant all privileges on FD.FD_USER_PASSWORD_RESET_TOKEN to FD_ADMIN;

-- password history/reset - end


-- FLEXDEPLOY-13577
DELETE FROM FD.PROJECT_OBJECT_ATTRIBUTE 
WHERE object_attr_def_id IN (
    SELECT object_attr_def_id 
    FROM FD.object_attribute_def 
    WHERE object_attribute_code IN ('UPDATE_CONNECTIONS', 'UPDATE_PARAMETERS', 'UPDATE_CREDENTIALS', 'REFRESH_SEMANTIC_MODEL', 'SKIP_REPORT')
);
update FD.object_attribute_def set IS_ACTIVE='N' where object_attribute_code in ('UPDATE_CONNECTIONS','UPDATE_PARAMETERS','UPDATE_CREDENTIALS','REFRESH_SEMANTIC_MODEL','SKIP_REPORT');

-- FLEXDEPLOY-13577 - end

--leave at the end
commit;