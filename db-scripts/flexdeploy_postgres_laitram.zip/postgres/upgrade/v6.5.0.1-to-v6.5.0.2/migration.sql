-- 6.5.0.2
insert into FD.FD_FLEXDEPLOY_VERSION values('6.5.0.2',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

-- Fix to view integration instance property set - start
CREATE OR REPLACE VIEW FD.VINTGINSTPROPERTYSET
AS  
    SELECT  PS.PROPERTY_SET_ID, PS.PROPERTY_SET_NAME, PS.OWNER_TYPE, SPLIT_PART(PS.PROPERTY_SET_NAME, '_', 1) AS OWNER_SUB_TYPE
        FROM FD.PROPERTY_SET PS WHERE PS.OWNER_TYPE='SCM'
    UNION
    SELECT  PS.PROPERTY_SET_ID, PS.PROPERTY_SET_NAME, PS.OWNER_TYPE, ITS.NAME AS OWNER_SUB_TYPE
        FROM FD.PROPERTY_SET PS 
        JOIN FD.ISSUETRACKINGSYSTEM ITS ON PS.OWNER_ID = ITS.ISSUETRACKINGSYSTEMID
        WHERE PS.OWNER_TYPE='ITS'
    UNION
    SELECT PS.PROPERTY_SET_ID, PS.PROPERTY_SET_NAME, PS.OWNER_TYPE, CMS.NAME AS OWNER_SUB_TYPE
        FROM FD.PROPERTY_SET PS 
        JOIN FD.CMS CMS ON PS.OWNER_ID = CMS.CMS_ID 
        WHERE PS.OWNER_TYPE='CMS'
    UNION
    SELECT PS.PROPERTY_SET_ID, PS.PROPERTY_SET_NAME, PS.OWNER_TYPE, TT.TESTING_TOOL_NAME AS OWNER_SUB_TYPE
        FROM FD.PROPERTY_SET PS 
        JOIN FD.TESTING_TOOL TT ON PS.OWNER_ID = TT.TESTING_TOOL_ID
        WHERE PS.OWNER_TYPE='TESTING_TOOL'
    UNION
    SELECT PS.PROPERTY_SET_ID, PS.PROPERTY_SET_NAME, PS.OWNER_TYPE, AP.NAME AS OWNER_SUB_TYPE
        FROM FD.PROPERTY_SET PS 
        JOIN FD.ACCOUNT_PROVIDER AP ON PS.OWNER_ID = AP.ACCOUNT_PROVIDER_ID
        WHERE PS.OWNER_TYPE = AP.TYPE;

GRANT ALL PRIVILEGES ON FD.VINTGINSTPROPERTYSET TO FD_ADMIN;
-- Fix to view integration instance property set - end

UPDATE FD.PROPERTY_SET SET OWNER_TYPE='SCANTOOL' WHERE OWNER_TYPE='ANALYSISTOOL';

-- Add Subtype to FlexField Metadata - start
ALTER TABLE FD.FLEX_FIELD_METADATA ADD SUB_DATATYPE VARCHAR(50);
-- Add Subtype to FlexField Metadata - end

-- add audit columns for VSM_MEASUREMENT_STATE - start
ALTER TABLE FD.VSM_MEASUREMENT_STATE  ADD CREATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP ;
ALTER TABLE FD.VSM_MEASUREMENT_STATE  ADD CREATED_BY VARCHAR(128);
ALTER TABLE FD.VSM_MEASUREMENT_STATE  ADD UPDATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP ;
ALTER TABLE FD.VSM_MEASUREMENT_STATE  ADD UPDATED_BY VARCHAR(128);
ALTER TABLE FD.VSM_MEASUREMENT_STATE  ADD VERSION_NUMBER NUMERIC(8, 0);
update FD.VSM_MEASUREMENT_STATE set VERSION_NUMBER=1;
-- add audit columns for VSM_MEASUREMENT_STATE - end

-- Update Float DataType to Double in FlexField Metadata and make display name nullable - start
UPDATE FD.FLEX_FIELD_METADATA SET DATATYPE = 'Double' WHERE DATATYPE LIKE 'Float';
ALTER TABLE FD.FLEX_FIELD_METADATA ALTER COLUMN DISPLAY_NAME DROP NOT NULL;
-- Update Float DataType to Double in FlexField Metadata and make display name nullable - end

-- match priority columns - start
DROP VIEW IF EXISTS FD.VACTVPROJWFULLPATH;

ALTER TABLE FD.PROJECT ALTER COLUMN  DEPLOY_PRIORITY TYPE NUMERIC(8, 0);
ALTER TABLE FD.WORKFLOW_REQUEST  ALTER COLUMN  PRIORITY TYPE NUMERIC(8);

  CREATE OR REPLACE VIEW FD.VACTVPROJWFULLPATH (PROJECT_ID, FOLDER_ID, PROJECT_NAME, PARTIAL_DEPLOYMENTS, 
DEPLOY_PRIORITY, PROJECT_TYPE, FULL_PATH) AS 
select p.PROJECT_ID, p.FOLDER_ID, p.PROJECT_NAME, p.PARTIAL_DEPLOYMENTS, p.DEPLOY_PRIORITY, p.PROJECT_TYPE, fp.full_path
from FD.PROJECT P, 
(with recursive folders (project_id, folder_id, parent_folder_id, folder_name, lvl) as (
  select p.project_id, f.folder_id, f.parent_folder_id, f.folder_name, 0 lvl
  from FD.FOLDER f, FD.PROJECT p
  where f.folder_id = p.folder_id and p.IS_ACTIVE='Y'
  union all
  select p2. project_id, f2.folder_id, f2.parent_folder_id, f2.folder_name, f3.lvl + 1
  from folders f3, fd.folder f2, fd.project p2
  where f3.parent_folder_id = f2.folder_id and p2.project_id = f3.project_id)
select folders.project_id, string_agg(folders.folder_name, '/' order by lvl desc) as full_path from folders
group by folders.project_id) fp where p.IS_ACTIVE='Y' and p.project_id = fp.project_id;

GRANT ALL PRIVILEGES ON FD.VACTVPROJWFULLPATH TO FD_ADMIN;
-- match priority columns - end

-- realm changes - start
UPDATE fd.fd_realm SET attribute10 = 'N' WHERE realm_class = 'flexagon.fd.ui.security.FlexActiveDirectoryRealm';

UPDATE fd.fd_realm
SET realm_class   = 'flexagon.fd.ui.security.FlexLDAPRealm'
WHERE realm_class = 'flexagon.fd.ui.security.FlexActiveDirectoryRealm';
-- realm changes - end

commit;