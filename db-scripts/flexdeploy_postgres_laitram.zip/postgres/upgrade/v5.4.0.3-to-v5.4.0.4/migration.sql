-- 5.4.0.4
insert into FD.FD_FLEXDEPLOY_VERSION values('5.4.0.4',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

drop VIEW FD.VTESTAUTOMATIONRESULT;
      
CREATE OR REPLACE VIEW FD.VTESTAUTOMATIONRESULT
AS select test_run.project_id,
       test_run.environment_id,
       test_run.instance_id,
       test_run.project_stream_id,
       test_run.test_type_id,
       CAST(test_run.start_time AS DATE) as test_date,
       ts.Test_set_id,
       ts.test_set_name,
       td.test_definition_id,
       td.test_definition_name,
       tr.test_case_name,
       tr.status,
       tr.duration,
       tr.MinRespTime,
       tr.MaxRespTime,
       tr.AvgRespTime,
       e.environment_name,
       e.environment_code,
       tdr.start_time,
       f.folder_name
from FD.TEST_RESULT tr, FD.TEST_DEFINITION_RUN tdr, FD.TEST_DEFINITION td, FD.TEST_SET_RUN tsr, FD.TEST_SET ts, FD.TEST_RUN test_run, FD.ENVIRONMENT e, FD.PROJECT p, FD.FOLDER f
where tr.test_definition_run_id = tdr.test_definition_run_id and
      tdr.Test_definition_id = td.Test_definition_id and
      tdr.test_set_run_id = tsr.test_set_run_id and
      tsr.test_set_id = ts.test_set_id and
      tsr.Test_run_id = test_run.Test_run_id and
      test_run.environment_id = e.environment_id and
      test_run.project_id = p.project_id and
      p.folder_id = f.folder_id;
      
grant all privileges on FD.VTESTAUTOMATIONRESULT to FD_ADMIN;

ALTER TABLE FD.FD_USER ALTER COLUMN USER_NAME TYPE VARCHAR(128);