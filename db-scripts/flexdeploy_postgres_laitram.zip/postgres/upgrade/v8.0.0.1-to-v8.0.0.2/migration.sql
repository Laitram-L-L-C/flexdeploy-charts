insert into FD.FD_FLEXDEPLOY_VERSION values('8.0.0.2',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

CREATE INDEX FDIX822 ON FD.GROOVY_SCRIPT_LOG (OBJECT_TYPE, OBJECT_ID, PARENT_OBJECT_ID);

-- delete property sets from deleted plugins
delete from fd.inst_property_set where property_set_id in (select property_set_id from fd.property_set where OWNER_TYPE = 'PLUGIN' and OWNER_ID not in (select plugin_id from fd.plugin));
delete from fd.property_set_key_def where property_set_id in (select property_set_id from fd.property_set where OWNER_TYPE = 'PLUGIN' and OWNER_ID not in (select plugin_id from fd.plugin));
delete from fd.property_set where OWNER_TYPE = 'PLUGIN' and OWNER_ID not in (select plugin_id from fd.plugin);

-- leave at the end
commit;