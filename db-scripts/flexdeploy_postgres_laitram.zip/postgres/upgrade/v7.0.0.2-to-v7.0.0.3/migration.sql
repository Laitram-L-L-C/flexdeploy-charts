-- 7.0.0.3
insert into FD.FD_FLEXDEPLOY_VERSION values('7.0.0.3',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

DROP VIEW FD.VRPTENVPROJSTAT;

CREATE OR REPLACE VIEW FD.VRPTENVPROJSTAT as
SELECT we.workflow_execution_id,
  p.folder_id,
  p.project_id,
  p.project_name,
  pv.project_version_name,
  pv.scm_revision scm_revision,
  W.WORKFLOW_TYPE,
  W.WORKFLOW_ID,
  W.WORKFLOW_NAME,
  WV.WORKFLOW_VERSION,
  pv.all_files_requested,
  e.environment_id,
  e.environment_name,
  i.instance_id,
  i.instance_name,
  we.execution_status,
  pw.project_workflow_type,
  we.start_time,
  we.end_time,
  wr.created_by requested_by,
  wr.created_on requested_on,
  wr.flex_field_1,
  wr.flex_field_2,
  wr.flex_field_3,
  wr.flex_field_4,
  wr.flex_field_5,
  wr.flex_field_6,
  wr.flex_field_7,
  wr.flex_field_8,
  wr.flex_field_9,
  wr.flex_field_10,
  pv.flex_field_1 build_flex_field1,
  pv.flex_field_2 build_flex_field2,
  pv.flex_field_3 build_flex_field3,
  pv.flex_field_4 build_flex_field4,
  pv.flex_field_5 build_flex_field5,
  pv.flex_field_6 build_flex_field6,
  pv.flex_field_7 build_flex_field7,
  pv.flex_field_8 build_flex_field8,
  pv.flex_field_9 build_flex_field9,
  pv.flex_field_10 build_flex_field10,
  NULL package_name,
  NULL package_created_by,
  NULL package_created_on,
  NULL package_updated_by,
  NULL package_updated_on,
  '' object_path,
  '' object_type,
  '' sub_component_name,
  '' sub_component_type,
  p.partial_deployments,
  f.folder_name,
  wr.rel_definition_id,
  wr.rel_snapshot_id,
  rd.rel_name,
  rd.rel_status,
  pd.name pipeline_name,
  rs.rel_snapshot,
  rs.created_by snapshot_submitted_by,
  wr.workflow_request_id,
  wr.pipeline_stage_exec_id,
  (
   SELECT STRING_AGG(WI.WORK_ITEM_NUMBER,', '
        ORDER BY WI.WORK_ITEM_NUMBER)
      FROM FD.WORKFLOW_EXECUTION_WORK_ITEM EXE_WI,
        FD.WORK_ITEM WI
      WHERE EXE_WI.WORKFLOW_EXECUTION_ID = WE.WORKFLOW_EXECUTION_ID
          AND WI.WORK_ITEM_ID                = EXE_WI.WORK_ITEM_ID
       ) AS WORK_ITEM_IDS,
  (SELECT STRING_AGG(TICKET.TICKET_NUMBER,', '
          ORDER BY TICKET.TICKET_NUMBER)
        FROM FD.WORKFLOW_REQUEST_TICKET WRT,
             FD.CMS_TICKET TICKET
        WHERE WRT.CMS_TICKET_ID    =TICKET.CMS_TICKET_ID
          AND WRT.WORKFLOW_REQUEST_ID=WR.WORKFLOW_REQUEST_ID
       ) external_ticket,
  pv.project_version_id,
  (
  SELECT STRING_AGG(HT.ACTION_BY,', '
        ORDER BY HT.ACTION_BY)
        FROM FD.HUMAN_TASK HT
        WHERE (HT.WORKFLOW_REQUEST_ID  =WR.WORKFLOW_REQUEST_ID
          OR (HT.PIPELINE_STAGE_EXEC_ID  =WR.PIPELINE_STAGE_EXEC_ID
           AND HT.PIPELINE_STAGE_GATE_ID IS NOT NULL)
          OR HT.WORKFLOW_EXECUTION_ID    = WE.PREDEPLOY_WORKFLOW_EXEC_ID)
          AND HT.TASK_STATUS             ='APPROVED'
          AND HT.TASK_TYPE              IN ('PRE_DEPLOY_REVIEW', 'APPROVAL')
  ) APPROVED_BY_USERNAMES,
  ps.stream_name,
  wr.force_deploy as force,
  wr.folder_request_id,
  NULL PKG_STATUS,
  NULL COMMIT_USER
FROM fd.workflow_execution we,
  fd.project p,
  fd.project_version pv
  left outer join fd.project_stream ps on pv.project_stream_id = ps.project_stream_id,
  fd.environment e,
  fd.project_workflow pw,
  fd.instance i,
  fd.project_wf_current_status pwcs,
  fd.workflow_request wr
  LEFT OUTER JOIN fd.rel_definition rd ON wr.rel_definition_id = rd.rel_definition_id
  LEFT OUTER JOIN fd.pipeline_definition pd ON rd.pipeline_definition_id = pd.pipeline_definition_id
  LEFT OUTER JOIN fd.rel_snapshot rs ON wr.rel_snapshot_id = rs.rel_snapshot_id,
  fd.folder f,
  FD.WORKFLOW_VERSION wv,
  FD.WORKFLOW W
WHERE p.project_id = we.project_id
  AND p.folder_id = f.folder_id
  AND pv.project_version_id = we.project_version_id
  AND e.environment_id = we.environment_id
  AND i.instance_id = we.instance_id
  AND pw.project_workflow_id = we.project_workflow_id
  AND p.partial_deployments = 'N'
  AND pw.project_workflow_type = 'DEPLOY'
  AND wr.workflow_request_id = we.workflow_request_id
  AND we.workflow_execution_id = pwcs.workflow_execution_id
  and WV.WORKFLOW_VERSION_ID = WE.WORKFLOW_VERSION_ID
  and W.WORKFLOW_ID = WE.WORKFLOW_ID
UNION ALL
SELECT we.workflow_execution_id,
  p.folder_id,
  p.project_id,
  p.project_name,
  pv.project_version_name,
  pkgobj.scm_revision scm_revision,
  W.WORKFLOW_TYPE,
  W.WORKFLOW_ID,
  W.WORKFLOW_NAME,
  WV.WORKFLOW_VERSION,
  pv.all_files_requested,
  e.environment_id,
  e.environment_name,
  i.instance_id,
  i.instance_name,
  we.execution_status,
  pw.project_workflow_type,
  we.start_time,
  we.end_time,
  wr.created_by requested_by,
  wr.created_on requested_on,
  wr.flex_field_1,
  wr.flex_field_2,
  wr.flex_field_3,
  wr.flex_field_4,
  wr.flex_field_5,
  wr.flex_field_6,
  wr.flex_field_7,
  wr.flex_field_8,
  wr.flex_field_9,
  wr.flex_field_10,
  pv.flex_field_1 build_flex_field1,
  pv.flex_field_2 build_flex_field2,
  pv.flex_field_3 build_flex_field3,
  pv.flex_field_4 build_flex_field4,
  pv.flex_field_5 build_flex_field5,
  pv.flex_field_6 build_flex_field6,
  pv.flex_field_7 build_flex_field7,
  pv.flex_field_8 build_flex_field8,
  pv.flex_field_9 build_flex_field9,
  pv.flex_field_10 build_flex_field10,
  pv.package_name as package_name,
  PP.CREATED_BY AS PACKAGE_CREATED_BY,
  PP.CREATED_ON AS PACKAGE_CREATED_ON,
  PP.UPDATED_BY AS PACKAGE_UPDATED_BY,
  PP.UPDATED_ON AS PACKAGE_UPDATED_ON,  
  prjobj.object_path object_path,
  objtyp.object_type_code object_type,
  prjobj.sub_component_name,
  prjobj.sub_component_type,
  p.partial_deployments,
  f.folder_name,
  wr.rel_definition_id,
  wr.rel_snapshot_id,
  rd.rel_name,
  rd.rel_status,
  pd.name pipeline_name,
  rs.rel_snapshot,
  rs.created_by snapshot_submitted_by,
  wr.workflow_request_id,
  wr.pipeline_stage_exec_id,
  (SELECT STRING_AGG(WI.WORK_ITEM_NUMBER,', '
        ORDER BY WI.WORK_ITEM_NUMBER)
      FROM FD.WORKFLOW_EXECUTION_WORK_ITEM EXE_WI,
        FD.WORK_ITEM WI
      WHERE EXE_WI.WORKFLOW_EXECUTION_ID = WE.WORKFLOW_EXECUTION_ID
          AND WI.WORK_ITEM_ID                = EXE_WI.WORK_ITEM_ID
       ) AS WORK_ITEM_IDS,
  (SELECT STRING_AGG(TICKET.TICKET_NUMBER,', '
          ORDER BY TICKET.TICKET_NUMBER)
        FROM FD.WORKFLOW_REQUEST_TICKET WRT,
             FD.CMS_TICKET TICKET
        WHERE WRT.CMS_TICKET_ID    =TICKET.CMS_TICKET_ID
          AND WRT.WORKFLOW_REQUEST_ID=WR.WORKFLOW_REQUEST_ID
       ) external_ticket,
  pv.project_version_id,
    (SELECT STRING_AGG(HT.ACTION_BY,', '
          ORDER BY HT.ACTION_BY)
        FROM FD.HUMAN_TASK HT
        WHERE (HT.WORKFLOW_REQUEST_ID  =WR.WORKFLOW_REQUEST_ID
          OR (HT.PIPELINE_STAGE_EXEC_ID  =WR.PIPELINE_STAGE_EXEC_ID
            AND HT.PIPELINE_STAGE_GATE_ID IS NOT NULL)
          OR HT.WORKFLOW_EXECUTION_ID    = WE.PREDEPLOY_WORKFLOW_EXEC_ID)
          AND HT.TASK_STATUS             ='APPROVED'
          AND HT.TASK_TYPE              IN ('PRE_DEPLOY_REVIEW', 'APPROVAL')
       ) APPROVED_BY_USERNAMES,
  ps.stream_name,
   wr.force_deploy as force,
  wr.folder_request_id,
  (SELECT STRING_AGG(PKGEXEC.EXECUTION_STATUS,','
    ORDER BY PKGEXEC.EXECUTION_STATUS)
   FROM FD.PLUGIN_EXECUTION PEXEC,
        FD.PACKAGE_OBJECT_EXECUTION PKGEXEC
      WHERE PKGOBJ.PACKAGE_OBJECT_ID IS NOT NULL
        AND PKGEXEC.PACKAGE_OBJECT_ID   = PKGOBJ.PACKAGE_OBJECT_ID
        AND PKGEXEC.PLUGIN_EXECUTION_ID = PEXEC.PLUGIN_EXECUTION_ID
        AND PEXEC.WORKFLOW_EXECUTION_ID = WE.WORKFLOW_EXECUTION_ID
        AND W.WORKFLOW_TYPE             ='DEPLOY'
      ) PKG_STATUS,
      POR.COMMIT_USER
FROM fd.workflow_execution we,
  fd.project p,
  fd.project_version pv
  LEFT OUTER JOIN fd.project_package pp ON pv.project_id = pp.project_id
  AND pv.package_name = pp.package_name
  left outer join fd.project_stream ps on ps.project_stream_id = pv.project_stream_id,
  fd.environment e,
  fd.project_workflow pw,
  fd.instance i,
  fd.package_obj_current_status pkjobjcs,
  fd.workflow_request wr
  LEFT OUTER JOIN fd.rel_definition rd ON wr.rel_definition_id = rd.rel_definition_id
  LEFT OUTER JOIN fd.pipeline_definition pd ON rd.pipeline_definition_id = pd.pipeline_definition_id
  LEFT OUTER JOIN fd.rel_snapshot rs ON wr.rel_snapshot_id = rs.rel_snapshot_id,
  fd.package_object pkgobj
  LEFT OUTER JOIN fd.project_object_revision por ON por.project_object_id=pkgobj.project_object_id
  AND por.scm_revision = pkgobj.scm_revision,
  fd.project_object prjobj,
  fd.object_type objtyp,
  fd.folder f,
  FD.WORKFLOW_VERSION WV,
  FD.WORKFLOW W
WHERE p.project_id = we.project_id
  AND p.folder_id = f.folder_id
  AND pv.project_version_id = we.project_version_id
  AND e.environment_id = we.environment_id
  AND i.instance_id = we.instance_id
  AND pw.project_workflow_id = we.project_workflow_id
  AND p.partial_deployments = 'Y'
  AND pw.project_workflow_type = 'DEPLOY'
  AND wr.workflow_request_id = we.workflow_request_id
  AND we.workflow_execution_id = pkjobjcs.workflow_execution_id
  AND p.project_id = pv.project_id
  AND pkgobj.project_object_id = pkjobjcs.project_object_id
  AND pv.project_version_id = pkgobj.project_version_id
  AND pkgobj.project_object_id = prjobj.project_object_id
  AND prjobj.object_type_id = objtyp.object_type_id
  and WV.WORKFLOW_VERSION_ID = WE.WORKFLOW_VERSION_ID
  and W.WORKFLOW_ID = WE.WORKFLOW_ID;
  
  grant all privileges on FD.VRPTENVPROJSTAT to FD_ADMIN;
  
ALTER TABLE FD.WORKFLOW_EXECUTION_REPORT ALTER COLUMN SUB_TYPE TYPE VARCHAR(4000);
update fd.pipeline_metadata set description = 'Select one or more stages to be skipped during snapshot execution. Requires ''Skip Stage Execution'' permission.' where key_code = 'FD_INTERNAL_SKIP_STAGES';

-- Groovy Script Log - start
ALTER TABLE FD.WEBHOOK_MESSAGE_LOG RENAME TO GROOVY_SCRIPT_LOG;

ALTER TABLE FD.GROOVY_SCRIPT_LOG DROP CONSTRAINT WEBHOOK_MESSAGE_LOG_FK1;
ALTER TABLE FD.GROOVY_SCRIPT_LOG DROP CONSTRAINT WEBHOOK_MESSAGE_LOG_PK;

ALTER TABLE FD.GROOVY_SCRIPT_LOG RENAME COLUMN WEBHOOK_MESSAGE_LOG_ID TO GROOVY_SCRIPT_LOG_ID;
ALTER TABLE FD.GROOVY_SCRIPT_LOG RENAME COLUMN WEBHOOK_MESSAGE_FUNCTION_ID TO OBJECT_ID;
ALTER TABLE FD.GROOVY_SCRIPT_LOG ADD CONSTRAINT GROOVY_SCRIPT_LOG_PK PRIMARY KEY(GROOVY_SCRIPT_LOG_ID);

ALTER TABLE FD.GROOVY_SCRIPT_LOG ADD OBJECT_TYPE VARCHAR(50);
UPDATE FD.GROOVY_SCRIPT_LOG SET OBJECT_TYPE = 'WEBHOOKMESSAGEFUNCTION';
ALTER TABLE FD.GROOVY_SCRIPT_LOG ALTER COLUMN OBJECT_TYPE SET NOT NULL; 

ALTER TABLE FD.GROOVY_SCRIPT_LOG DROP COLUMN UPDATED_ON;
ALTER TABLE FD.GROOVY_SCRIPT_LOG DROP COLUMN UPDATED_BY;
ALTER TABLE FD.GROOVY_SCRIPT_LOG DROP COLUMN VERSION_NUMBER;

ALTER TABLE FD.GROOVY_SCRIPT_LOG ADD PARENT_OBJECT_ID NUMERIC(20, 0) ;
-- Groovy Script Log - end

-- scheduled outgoing webhook - start
ALTER TABLE FD.EVENT_LISTENER ADD IS_SCHEDULE CHAR(1);

UPDATE FD.EVENT_LISTENER SET IS_SCHEDULE='N';

ALTER TABLE FD.EVENT_LISTENER ALTER COLUMN IS_SCHEDULE SET NOT NULL;

ALTER TABLE FD.EVENT_LISTENER ADD CRON_EXPRESSION VARCHAR(255);
-- scheduled outgoing webhook - end
  
-- leave at the end
commit;
