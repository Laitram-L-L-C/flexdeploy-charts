-- 5.6.0.0
insert into FD.FD_FLEXDEPLOY_VERSION values('5.6.0.0',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

CREATE TABLE FD.NOTIF_EVENT_TYPE 
(
  NOTIF_EVENT_TYPE_ID NUMERIC(20, 0) NOT NULL 
, NOTIF_EVENT_NAME VARCHAR(50) NOT NULL 
, NOTIF_EVENT_DISPLAY_NAME VARCHAR(50) NOT NULL 
, NOTIF_TEMPLATE_ID NUMERIC(20) 
, DESCRIPTION VARCHAR(255) 
, CREATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP NOT NULL 
, CREATED_BY VARCHAR(128) NOT NULL 
, UPDATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP NOT NULL 
, UPDATED_BY VARCHAR(128) NOT NULL 
, VERSION_NUMBER NUMERIC(8, 0) NOT NULL 
, CONSTRAINT NOTIF_EVENT_TYPE_PK PRIMARY KEY 
  (
    NOTIF_EVENT_TYPE_ID 
  )
);

CREATE TABLE FD.NOTIF_TEMPLATE 
(
  NOTIF_TEMPLATE_ID NUMERIC(20, 0) NOT NULL 
, NOTIF_TEMPLATE_NAME VARCHAR(50) NOT NULL  
, IS_CUSTOM CHAR(1) NOT NULL 
, CREATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP NOT NULL 
, CREATED_BY VARCHAR(128) NOT NULL 
, UPDATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP NOT NULL 
, UPDATED_BY VARCHAR(128) NOT NULL 
, VERSION_NUMBER NUMERIC(8, 0) NOT NULL 
, CONSTRAINT NOTIF_TEMPLATE_PK PRIMARY KEY 
  (
    NOTIF_TEMPLATE_ID 
  )
);

CREATE TABLE FD.NOTIF_TEMPLATE_COMPONENT 
(
  NOTIF_TEMPLATE_COMPONENT_ID NUMERIC(20, 0) NOT NULL 
, NOTIF_TEMPLATE_ID NUMERIC(20, 0) NOT NULL 
, MEDIUM_TYPE VARCHAR(50) NOT NULL 
, COMPONENT_TYPE VARCHAR(50) NOT NULL 
, TEMPLATE_TEXT TEXT NOT NULL 
, CREATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP NOT NULL 
, CREATED_BY VARCHAR(128) NOT NULL 
, UPDATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP NOT NULL 
, UPDATED_BY VARCHAR(128) NOT NULL 
, VERSION_NUMBER NUMERIC(8, 0) NOT NULL 
, CONSTRAINT NOTIF_TEMPLATE_COMPONENT_PK PRIMARY KEY 
  (
    NOTIF_TEMPLATE_COMPONENT_ID 
  ) 
);

ALTER TABLE FD.NOTIF_EVENT_TYPE
ADD CONSTRAINT NOTIF_EVENT_TYPE_UK1 UNIQUE 
(
  NOTIF_EVENT_NAME 
);

ALTER TABLE FD.NOTIF_TEMPLATE
ADD CONSTRAINT NOTIF_TEMPLATE_UK1 UNIQUE 
(
  NOTIF_TEMPLATE_NAME 
);

ALTER TABLE FD.NOTIF_TEMPLATE_COMPONENT
ADD CONSTRAINT NOTIF_TEMPLATE_COMPONENT_UK1 UNIQUE 
(
  NOTIF_TEMPLATE_ID 
, MEDIUM_TYPE 
, COMPONENT_TYPE 
);

ALTER TABLE FD.NOTIF_EVENT_TYPE
ADD CONSTRAINT NOTIF_EVENT_TYPE_FK1 FOREIGN KEY
(
  NOTIF_TEMPLATE_ID 
)
REFERENCES FD.NOTIF_TEMPLATE
(
  NOTIF_TEMPLATE_ID 
);

ALTER TABLE FD.NOTIF_TEMPLATE_COMPONENT
ADD CONSTRAINT NOTIF_TEMPLATE_COMPONENT_FK1 FOREIGN KEY
(
  NOTIF_TEMPLATE_ID 
)
REFERENCES FD.NOTIF_TEMPLATE
(
  NOTIF_TEMPLATE_ID 
);

grant all privileges on FD.NOTIF_EVENT_TYPE to fd_admin;
grant all privileges on FD.NOTIF_TEMPLATE to fd_admin;
grant all privileges on FD.NOTIF_TEMPLATE_COMPONENT to fd_admin;

CREATE TABLE FD.SAVED_QUERY
(
  SAVED_QUERY_ID NUMERIC(20, 0) NOT NULL 
, PAGE_NAME VARCHAR(50) NOT NULL 
, SAVED_QUERY_NAME VARCHAR(50) NOT NULL
, SAVED_QUERY_TYPE VARCHAR(50) NOT NULL
, SAVED_QUERY_OWNER_ID VARCHAR(128)
, SAVED_QUERY_DATA TEXT
, CREATED_ON TIMESTAMP NOT NULL 
, CREATED_BY VARCHAR(128) NOT NULL 
, UPDATED_ON TIMESTAMP NOT NULL 
, UPDATED_BY VARCHAR(128) NOT NULL 
, VERSION_NUMBER NUMERIC(8, 0) NOT NULL 
, CONSTRAINT SAVED_QUERY_ID PRIMARY KEY 
  (
    SAVED_QUERY_ID
  ) 
);

CREATE UNIQUE INDEX SAVED_QUERY_UK1
	ON FD.SAVED_QUERY 
(PAGE_NAME, SAVED_QUERY_NAME, SAVED_QUERY_TYPE, coalesce(SAVED_QUERY_OWNER_ID,'-1'));

grant all privileges on FD.SAVED_QUERY to FD_ADMIN;

drop VIEW FD.VRPTENVPROJSTAT;

CREATE OR REPLACE VIEW FD.VRPTENVPROJSTAT as
SELECT we.workflow_execution_id,
  p.folder_id,
  p.project_id,
  p.project_name,
  pv.project_version_name,
  pv.scm_revision scm_revision,
  pv.all_files_requested,
  e.environment_id,
  e.environment_name,
  i.instance_id,
  i.instance_name,
  we.execution_status,
  pw.project_workflow_type,
  we.start_time,
  we.end_time,
  wr.created_by requested_by,
  wr.created_on requested_on,
  wr.flex_field_1,
  wr.flex_field_2,
  wr.flex_field_3,
  wr.flex_field_4,
  wr.flex_field_5,
  wr.flex_field_6,
  wr.flex_field_7,
  wr.flex_field_8,
  wr.flex_field_9,
  wr.flex_field_10,
  pv.flex_field_1 build_flex_field1,
  pv.flex_field_2 build_flex_field2,
  pv.flex_field_3 build_flex_field3,
  pv.flex_field_4 build_flex_field4,
  pv.flex_field_5 build_flex_field5,
  pv.flex_field_6 build_flex_field6,
  pv.flex_field_7 build_flex_field7,
  pv.flex_field_8 build_flex_field8,
  pv.flex_field_9 build_flex_field9,
  pv.flex_field_10 build_flex_field10,
  NULL package_name,
  '' object_path,
  p.partial_deployments,
  f.folder_name,
  wr.rel_definition_id,
  rd.rel_name,
  pd.name pipeline_name,
  rs.rel_snapshot,
  rs.created_by snapshot_submitted_by,
  wr.workflow_request_id,
  wr.folder_request_id,
  wr.pipeline_stage_exec_id,
  (
    SELECT string_agg(
        ISSUE_NUMBER,
        ', '
        ORDER BY ISSUE_NUMBER
      )
    FROM FD.WORKFLOW_REQUEST_CMS_ISSUE
    WHERE WORKFLOW_REQUEST_ID = WR.WORKFLOW_REQUEST_ID
  ) external_ticket,
  pv.project_version_id,
  ps.stream_name
FROM FD.WORKFLOW_EXECUTION we,
  FD.PROJECT p,
  FD.PROJECT_VERSION pv
  left outer join FD.PROJECT_STREAM ps on pv.project_stream_id = ps.project_stream_id,
  FD.ENVIRONMENT e,
  FD.PROJECT_WORKFLOW pw,
  FD.INSTANCE i,
  FD.PROJECT_WF_CURRENT_STATUS pwcs,
  FD.WORKFLOW_REQUEST wr
  LEFT OUTER JOIN FD.REL_DEFINITION rd ON wr.rel_definition_id = rd.rel_definition_id
  LEFT OUTER JOIN FD.PIPELINE_DEFINITION pd ON rd.pipeline_definition_id = pd.pipeline_definition_id
  LEFT OUTER JOIN FD.REL_SNAPSHOT rs ON wr.rel_snapshot_id = rs.rel_snapshot_id,
  FD.FOLDER f
WHERE p.project_id = we.project_id
  AND p.folder_id = f.folder_id
  AND pv.project_version_id = we.project_version_id
  AND e.environment_id = we.environment_id
  AND i.instance_id = we.instance_id
  AND pw.project_workflow_id = we.project_workflow_id
  AND p.partial_deployments = 'N'
  AND pw.project_workflow_type = 'DEPLOY'
  AND wr.workflow_request_id = we.workflow_request_id
  AND we.workflow_execution_id = pwcs.workflow_execution_id
UNION ALL
SELECT we.workflow_execution_id,
  p.folder_id,
  p.project_id,
  p.project_name,
  pv.project_version_name,
  pkgobj.scm_revision scm_revision,
  pv.all_files_requested,
  e.environment_id,
  e.environment_name,
  i.instance_id,
  i.instance_name,
  we.execution_status,
  pw.project_workflow_type,
  we.start_time,
  we.end_time,
  wr.created_by requested_by,
  wr.created_on requested_on,
  wr.flex_field_1,
  wr.flex_field_2,
  wr.flex_field_3,
  wr.flex_field_4,
  wr.flex_field_5,
  wr.flex_field_6,
  wr.flex_field_7,
  wr.flex_field_8,
  wr.flex_field_9,
  wr.flex_field_10,
  pv.flex_field_1 build_flex_field1,
  pv.flex_field_2 build_flex_field2,
  pv.flex_field_3 build_flex_field3,
  pv.flex_field_4 build_flex_field4,
  pv.flex_field_5 build_flex_field5,
  pv.flex_field_6 build_flex_field6,
  pv.flex_field_7 build_flex_field7,
  pv.flex_field_8 build_flex_field8,
  pv.flex_field_9 build_flex_field9,
  pv.flex_field_10 build_flex_field10,
  pv.package_name package_name,
  prjobj.object_path object_path,
  p.partial_deployments,
  f.folder_name,
  wr.rel_definition_id,
  rd.rel_name,
  pd.name pipeline_name,
  rs.rel_snapshot,
  rs.created_by snapshot_submitted_by,
  wr.workflow_request_id,
  wr.folder_request_id,
  wr.pipeline_stage_exec_id,
  (
    SELECT string_agg(
        ISSUE_NUMBER,
        ', '
        ORDER BY ISSUE_NUMBER
      )
    FROM FD.WORKFLOW_REQUEST_CMS_ISSUE
    WHERE WORKFLOW_REQUEST_ID = WR.WORKFLOW_REQUEST_ID
  ) external_ticket,
  pv.project_version_id,
  ps.stream_name
FROM FD.WORKFLOW_EXECUTION we,
  FD.PROJECT p,
  FD.PROJECT_VERSION pv
  left outer join FD.PROJECT_STREAM ps on pv.project_stream_id = ps.project_stream_id,
  FD.ENVIRONMENT e,
  FD.PROJECT_WORKFLOW pw,
  FD.INSTANCE i,
  FD.PACKAGE_OBJ_CURRENT_STATUS pkjobjcs,
  FD.WORKFLOW_REQUEST wr
  LEFT OUTER JOIN FD.REL_DEFINITION rd ON wr.rel_definition_id = rd.rel_definition_id
  LEFT OUTER JOIN FD.PIPELINE_DEFINITION pd ON rd.pipeline_definition_id = pd.pipeline_definition_id
  LEFT OUTER JOIN FD.REL_SNAPSHOT rs ON wr.rel_snapshot_id = rs.rel_snapshot_id,
  FD.PACKAGE_OBJECT pkgobj,
  FD.PROJECT_OBJECT prjobj,
  FD.FOLDER f
WHERE p.project_id = we.project_id
  AND p.folder_id = f.folder_id
  AND pv.project_version_id = we.project_version_id
  AND e.environment_id = we.environment_id
  AND i.instance_id = we.instance_id
  AND pw.project_workflow_id = we.project_workflow_id
  AND p.partial_deployments = 'Y'
  AND pw.project_workflow_type = 'DEPLOY'
  AND wr.workflow_request_id = we.workflow_request_id
  AND we.workflow_execution_id = pkjobjcs.workflow_execution_id
  AND p.project_id = pv.project_id
  AND pkgobj.project_object_id = pkjobjcs.project_object_id
  AND pv.project_version_id = pkgobj.project_version_id
  AND pkgobj.project_object_id = prjobj.project_object_id;

grant all privileges on FD.VRPTENVPROJSTAT to FD_ADMIN;

ALTER TABLE FD.PROJECT_TRIGGER ADD ACCOUNT_CODE VARCHAR(50);

CREATE TABLE FD.FD_OAUTH_TOKEN 
(
  FD_OAUTH_TOKEN_ID NUMERIC(20, 0) NOT NULL 
, FD_OAUTH_TOKEN_PROVIDER VARCHAR(50) NOT NULL 
, FD_OAUTH_TOKEN_CONTENT VARCHAR(4000) NOT NULL 
, IS_ENCRYPTED CHAR(1) DEFAULT 'N' NOT NULL 
, TOKEN_TYPE VARCHAR(50) NOT NULL 
, EXPIRATION TIMESTAMP WITH TIME ZONE 
, CREATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP NOT NULL 
, CREATED_BY VARCHAR(128) NOT NULL 
, UPDATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP NOT NULL 
, UPDATED_BY VARCHAR(128) NOT NULL 
, VERSION_NUMBER NUMERIC(8, 0) 
, CONSTRAINT FD_OAUTH_TOKEN_PK PRIMARY KEY 
  (
    FD_OAUTH_TOKEN_ID 
  )
);

ALTER TABLE FD.FD_OAUTH_TOKEN
ADD CONSTRAINT FD_OAUTH_TOKEN_UK1 UNIQUE 
(
  FD_OAUTH_TOKEN_PROVIDER 
, TOKEN_TYPE 
);

grant all privileges on FD.FD_OAUTH_TOKEN to FD_ADMIN;

COMMIT;

UPDATE FF.DB_PROPERTIES SET DB_PROPERTIES_NAME='FD_RELEASE_SETTINGS', SEQUENCE_NUMBER=1 WHERE DB_PROPERTIES_NAME='FD_GENERAL_SETTINGS' AND DB_PROPERTIES_KEY='FD_PIPELINE_RELEASE_ENABLED';
COMMIT;
