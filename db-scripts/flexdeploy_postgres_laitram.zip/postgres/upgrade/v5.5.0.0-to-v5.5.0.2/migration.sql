-- 5.5.0.2
insert into FD.FD_FLEXDEPLOY_VERSION values('5.5.0.2',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

ALTER TABLE FD.HUMAN_TASK ALTER COLUMN TASK_NOTES TYPE varchar(500);

COMMIT;