insert into FD.FD_FLEXDEPLOY_VERSION values('8.0.0.6',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

update fd.package_object 
set scm_revision = mt.scm_revision
from 
(
select distinct scm_revision,deduped12 from
( SELECT DISTINCT
    COUNT(*),
    left(
        scm_revision, 12
    ) AS deduped12
FROM
    (
        SELECT DISTINCT
            scm_revision
        FROM
            fd.scm_commit
        WHERE
            length(scm_revision) > 12
    ) as iq group by left(scm_revision,12) having count(*) =1
) as deduped inner join fd.scm_commit sc on
left(sc.scm_revision ,12) = deduped12
) as mt
where package_object_id
in
(select package_object_id from fd.package_object
where 
length(scm_revision) = 12
)
and mt.deduped12 = fd.package_object.scm_revision

;
--See how many package_object rows were left unconverted.
select count(*) from fd.package_object where length(scm_revision) = 12;



--project_object_revision - Delete the short where the same project_object_id + instance_id has both short and long revision that match up.

delete
from
	fd.project_object_revision por
where
	(project_object_id,
	scm_revision,
	instance_id) in 
(
	select
		por.project_object_id,
		por.scm_revision,
		por.instance_id
	from
		fd.project_object_revision por
	inner join fd.project_object_revision por2
on
		length(por.scm_revision) = 12
			and length(por2.scm_revision) > 12
				and por.project_object_id = por2.project_object_id
				and por.scm_revision = left(por2.scm_revision,
				12)
    inner join fd.instance i on i.instance_id = por.instance_id 
		and i.sub_group_code = 'GIT'
)
;


--project_object_revision - Update the short ones to be long using the scm_commit rows. This won't get all of them, but it's all we have.
update
	fd.project_object_revision
set
	scm_revision = mt.scm_revision
from
	(
	select
		distinct scm_revision,
		deduped12
	from
		(
		select
			distinct
    COUNT(*),
			left(
        scm_revision,
			12
    ) as deduped12
		from
			(
			select
				distinct
            scm_revision
			from
				fd.scm_commit
			where
				length(scm_revision) > 12
    ) as iq
		group by
			left(scm_revision,
			12)
		having
			count(*) = 1
) as deduped
	inner join fd.scm_commit sc on
		left(sc.scm_revision ,
		12) = deduped12
) as mt
where
	(project_object_id,
	fd.project_object_revision.scm_revision,
	instance_id)
in
(
	select
		project_object_id,
		scm_revision,
		por.instance_id
	from
		fd.project_object_revision por
	inner join fd.instance i on
		i.instance_id = por.instance_id
		and i.sub_group_code = 'GIT'
	where
		length(scm_revision) = 12
)
	and mt.deduped12 = fd.project_object_revision.scm_revision
;

--See how many por rows were left unconverted.
select count(*) from fd.project_object_revision where length(scm_revision) =12 ;

-- current activities perf

DROP VIEW IF EXISTS FD.VCURRENTPROJECTTASK;


CREATE OR REPLACE VIEW FD.VCURRENTPROJECTTASK
AS select
       we.workflow_execution_id,
       we.project_id,
       we.project_workflow_id,
       we.start_time,
       we.execution_status,
       we.project_version_id,
       we.environment_id,
       we.instance_id,
       we.last_exec_id,
       we.last_exec_start_time,
       we.last_exec_end_time,
       we.last_exec_status,
       we.last_exec_environment_id,
       we.last_exec_instance_id,
       p.project_name,
       pw.workflow_id,
       w.workflow_type,
       w.workflow_name,
       CAST(DATE_PART('hour', current_timestamp::timestamp - we.start_time::timestamp) AS int) Duration_hours,
       CAST(DATE_PART('minute', current_timestamp::timestamp - we.start_time::timestamp) AS int) Duration_minutes,
       env_inst.env_inst_id,
       env.ENVIRONMENT_NAME,
       ins.instance_name,
       env.ENVIRONMENT_CODE,
       ins.INSTANCE_CODE,
       CAST(DATE_PART('hour', we.last_exec_end_time::timestamp - we.last_exec_start_time::timestamp) AS int) last_hour_duration,
       CAST(DATE_PART('minute', we.last_exec_end_time::timestamp - we.last_exec_start_time::timestamp) AS int) last_minute_duration,
       CAST(EXTRACT(epoch FROM current_timestamp::timestamp - we.last_exec_end_time::timestamp)/3600 AS int) last_hour_ago,
       CAST(DATE_PART('minute', current_timestamp::timestamp - we.last_exec_end_time::timestamp) AS int) last_minute_ago,
       substr(we.last_exec_status,1,1) last_exec_state_id,
       last_env.ENVIRONMENT_NAME last_ENVIRONMENT_NAME,
       last_ins.instance_name last_instance_name,
       last_env.ENVIRONMENT_CODE last_ENVIRONMENT_CODE,
       last_ins.INSTANCE_CODE last_INSTANCE_CODE,
       pv.project_version_name project_version,
       f.folder_name,
       f.folder_id
from (
select workflow_execution_id,
       project_id,
       project_workflow_id,
       start_time,
       execution_status,
       project_version_id,
       environment_id,
       instance_id,
       FIRST_VALUE(workflow_execution_id) OVER (PARTITION BY project_id,  project_workflow_id order by case when execution_status='Running' then 0 else workflow_execution_id end desc) last_exec_id,
       FIRST_VALUE(start_time) OVER (PARTITION BY project_id,  project_workflow_id order by case when execution_status='Running' then 0 else workflow_execution_id end desc) last_exec_start_time,
       FIRST_VALUE(end_time) OVER (PARTITION BY project_id,  project_workflow_id order by case when execution_status='Running' then 0 else workflow_execution_id end desc) last_exec_end_time,
       FIRST_VALUE(execution_status) OVER (PARTITION BY project_id,  project_workflow_id order by case when execution_status='Running' then 0 else workflow_execution_id end desc) last_exec_status,
       FIRST_VALUE(environment_id) OVER (PARTITION BY project_id,  project_workflow_id order by case when execution_status='Running' then 0 else workflow_execution_id end desc) last_exec_environment_id,
       FIRST_VALUE(instance_id) OVER (PARTITION BY project_id,  project_workflow_id order by case when execution_status='Running' then 0 else workflow_execution_id end desc) last_exec_instance_id
from FD.WORKFLOW_EXECUTION
where parent_workflow_execution_id is null 
and (project_id,project_workflow_id) IN
    (SELECT DISTINCT project_id,
      project_workflow_id
    FROM FD.WORKFLOW_EXECUTION
    WHERE execution_status ='Running' 
	and parent_workflow_execution_id is null
    )
) we INNER JOIN FD.PROJECT p on we.project_id = p.PROJECT_ID
  INNER JOIN FD.PROJECT_WORKFLOW pw on we.project_workflow_id = pw.project_workflow_id 
  INNER JOIN FD.WORKFLOW w on pw.workflow_id = w.workflow_id
  INNER JOIN FD.ENVIRONMENT env on we.environment_id = env.environment_id
  INNER JOIN FD.INSTANCE ins on we.instance_id = ins.instance_id 
  INNER JOIN FD.ENVIRONMENT_INSTANCE env_inst on env_inst.instance_id = ins.instance_id and env_inst.environment_id = env.environment_id
  LEFT OUTER JOIN FD.ENVIRONMENT last_env on we.last_exec_environment_id = last_env.environment_id
  LEFT OUTER JOIN FD.INSTANCE last_ins on we.last_exec_instance_id = last_ins.instance_id
  INNER JOIN FD.PROJECT_VERSION pv on we.project_version_id = pv.project_version_id 
  INNER JOIN FD.FOLDER f on p.folder_id = f.folder_id 
where execution_status = 'Running'
       and w.workflow_type in ('BUILD', 'DEPLOY', 'TEST', 'UTILITY', 'PREDEPLOY');
       
GRANT ALL PRIVILEGES ON FD.VCURRENTPROJECTTASK TO FD_ADMIN;

-- current activities perf -end

-- leave at the end
commit;