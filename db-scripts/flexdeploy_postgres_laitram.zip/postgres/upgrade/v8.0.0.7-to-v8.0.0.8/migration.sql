insert into FD.FD_FLEXDEPLOY_VERSION values('8.0.0.8',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

UPDATE  fd.project_object_attribute poa
SET is_modified = 'Y' 
WHERE
    poa.object_attr_def_id IN (
        SELECT
            oa.object_attr_def_id
        FROM
            fd.object_type          ot, fd.object_attribute_def oa
        WHERE
            ot.object_type_id = oa.object_type_id
            AND ot.project_type = 'SALESFORCE'
            AND oa.object_attribute_code = 'SOURCE'
    )
    AND poa.attribute_value_small = 'Salesforce' 
    AND poa.is_modified='N';

-- leave at the end
commit;