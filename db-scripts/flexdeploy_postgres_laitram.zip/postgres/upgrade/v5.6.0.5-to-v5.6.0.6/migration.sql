-- 5.6.0.6
insert into FD.FD_FLEXDEPLOY_VERSION values('5.6.0.6',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

-- sub component - start
DROP VIEW IF EXISTS FD.VRPTENVPROJSTAT;

CREATE VIEW FD.VRPTENVPROJSTAT as
SELECT we.workflow_execution_id,
  p.folder_id,
  p.project_id,
  p.project_name,
  pv.project_version_name,
  pv.scm_revision scm_revision,
  pv.all_files_requested,
  e.environment_id,
  e.environment_name,
  i.instance_id,
  i.instance_name,
  we.execution_status,
  pw.project_workflow_type,
  we.start_time,
  we.end_time,
  wr.created_by requested_by,
  wr.created_on requested_on,
  wr.flex_field_1,
  wr.flex_field_2,
  wr.flex_field_3,
  wr.flex_field_4,
  wr.flex_field_5,
  wr.flex_field_6,
  wr.flex_field_7,
  wr.flex_field_8,
  wr.flex_field_9,
  wr.flex_field_10,
  pv.flex_field_1 build_flex_field1,
  pv.flex_field_2 build_flex_field2,
  pv.flex_field_3 build_flex_field3,
  pv.flex_field_4 build_flex_field4,
  pv.flex_field_5 build_flex_field5,
  pv.flex_field_6 build_flex_field6,
  pv.flex_field_7 build_flex_field7,
  pv.flex_field_8 build_flex_field8,
  pv.flex_field_9 build_flex_field9,
  pv.flex_field_10 build_flex_field10,
  NULL package_name,
  '' object_path,
  '' object_type,
  '' sub_component_name,
  '' sub_component_type,
  p.partial_deployments,
  f.folder_name,
  wr.rel_definition_id,
  rd.rel_name,
  rd.rel_status,
  pd.name pipeline_name,
  rs.rel_snapshot,
  rs.created_by snapshot_submitted_by,
  wr.workflow_request_id,
  wr.folder_request_id,
  wr.pipeline_stage_exec_id,
  (
    SELECT string_agg(
        ISSUE_NUMBER,
        ', '
        ORDER BY ISSUE_NUMBER
      )
    FROM FD.WORKFLOW_REQUEST_CMS_ISSUE
    WHERE WORKFLOW_REQUEST_ID = WR.WORKFLOW_REQUEST_ID
  ) external_ticket,
  pv.project_version_id,
  ps.stream_name
FROM FD.WORKFLOW_EXECUTION we,
  FD.PROJECT p,
  FD.PROJECT_VERSION pv
  left outer join FD.PROJECT_STREAM ps on pv.project_stream_id = ps.project_stream_id,
  FD.ENVIRONMENT e,
  FD.PROJECT_WORKFLOW pw,
  FD.INSTANCE i,
  FD.PROJECT_WF_CURRENT_STATUS pwcs,
  FD.WORKFLOW_REQUEST wr
  LEFT OUTER JOIN FD.REL_DEFINITION rd ON wr.rel_definition_id = rd.rel_definition_id
  LEFT OUTER JOIN FD.PIPELINE_DEFINITION pd ON rd.pipeline_definition_id = pd.pipeline_definition_id
  LEFT OUTER JOIN FD.REL_SNAPSHOT rs ON wr.rel_snapshot_id = rs.rel_snapshot_id,
  FD.FOLDER f
WHERE p.project_id = we.project_id
  AND p.folder_id = f.folder_id
  AND pv.project_version_id = we.project_version_id
  AND e.environment_id = we.environment_id
  AND i.instance_id = we.instance_id
  AND pw.project_workflow_id = we.project_workflow_id
  AND p.partial_deployments = 'N'
  AND pw.project_workflow_type = 'DEPLOY'
  AND wr.workflow_request_id = we.workflow_request_id
  AND we.workflow_execution_id = pwcs.workflow_execution_id
UNION ALL
SELECT we.workflow_execution_id,
  p.folder_id,
  p.project_id,
  p.project_name,
  pv.project_version_name,
  pkgobj.scm_revision scm_revision,
  pv.all_files_requested,
  e.environment_id,
  e.environment_name,
  i.instance_id,
  i.instance_name,
  we.execution_status,
  pw.project_workflow_type,
  we.start_time,
  we.end_time,
  wr.created_by requested_by,
  wr.created_on requested_on,
  wr.flex_field_1,
  wr.flex_field_2,
  wr.flex_field_3,
  wr.flex_field_4,
  wr.flex_field_5,
  wr.flex_field_6,
  wr.flex_field_7,
  wr.flex_field_8,
  wr.flex_field_9,
  wr.flex_field_10,
  pv.flex_field_1 build_flex_field1,
  pv.flex_field_2 build_flex_field2,
  pv.flex_field_3 build_flex_field3,
  pv.flex_field_4 build_flex_field4,
  pv.flex_field_5 build_flex_field5,
  pv.flex_field_6 build_flex_field6,
  pv.flex_field_7 build_flex_field7,
  pv.flex_field_8 build_flex_field8,
  pv.flex_field_9 build_flex_field9,
  pv.flex_field_10 build_flex_field10,
  pv.package_name package_name,
  prjobj.object_path object_path,
  objtyp.object_type_code object_type,
  prjobj.sub_component_name,
  prjobj.sub_component_type,
  p.partial_deployments,
  f.folder_name,
  wr.rel_definition_id,
  rd.rel_name,
  rd.rel_status,
  pd.name pipeline_name,
  rs.rel_snapshot,
  rs.created_by snapshot_submitted_by,
  wr.workflow_request_id,
  wr.folder_request_id,
  wr.pipeline_stage_exec_id,
  (
    SELECT string_agg(
        ISSUE_NUMBER,
        ', '
        ORDER BY ISSUE_NUMBER
      )
    FROM FD.WORKFLOW_REQUEST_CMS_ISSUE
    WHERE WORKFLOW_REQUEST_ID = WR.WORKFLOW_REQUEST_ID
  ) external_ticket,
  pv.project_version_id,
  ps.stream_name
FROM fd.workflow_execution we,
  fd.project p,
  fd.project_version pv
  left outer join fd.project_stream ps on ps.project_stream_id = pv.project_stream_id,
  fd.environment e,
  fd.project_workflow pw,
  fd.instance i,
  fd.package_obj_current_status pkjobjcs,
  fd.workflow_request wr
  LEFT OUTER JOIN fd.rel_definition rd ON wr.rel_definition_id = rd.rel_definition_id
  LEFT OUTER JOIN fd.pipeline_definition pd ON rd.pipeline_definition_id = pd.pipeline_definition_id
  LEFT OUTER JOIN fd.rel_snapshot rs ON wr.rel_snapshot_id = rs.rel_snapshot_id,
  fd.package_object pkgobj,
  fd.project_object prjobj,
  fd.object_type objtyp,
  fd.folder f
WHERE p.project_id = we.project_id
  AND p.folder_id = f.folder_id
  AND pv.project_version_id = we.project_version_id
  AND e.environment_id = we.environment_id
  AND i.instance_id = we.instance_id
  AND pw.project_workflow_id = we.project_workflow_id
  AND p.partial_deployments = 'Y'
  AND pw.project_workflow_type = 'DEPLOY'
  AND wr.workflow_request_id = we.workflow_request_id
  AND we.workflow_execution_id = pkjobjcs.workflow_execution_id
  AND p.project_id = pv.project_id
  AND pkgobj.project_object_id = pkjobjcs.project_object_id
  AND pv.project_version_id = pkgobj.project_version_id
  AND pkgobj.project_object_id = prjobj.project_object_id
  AND prjobj.object_type_id = objtyp.object_type_id;
-- FLEXDEPLOY-4061 Update to reports - start

GRANT ALL PRIVILEGES ON FD.VRPTENVPROJSTAT TO FD_ADMIN;

COMMIT;

ALTER TABLE FD.FD_OAUTH_TOKEN ADD FD_OAUTH_CLIENT_ID VARCHAR(100);

ALTER TABLE FD.FD_OAUTH_TOKEN 
DROP CONSTRAINT IF EXISTS FD_OAUTH_TOKEN_UK1;

DROP INDEX IF EXISTS FD.FD_OAUTH_TOKEN_UK1;

CREATE UNIQUE INDEX FD_OAUTH_TOKEN_UK1 
	ON FD.FD_OAUTH_TOKEN
(FD_OAUTH_TOKEN_PROVIDER, TOKEN_TYPE, FD_OAUTH_CLIENT_ID);
