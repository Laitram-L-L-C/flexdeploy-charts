insert into FD.FD_FLEXDEPLOY_VERSION values('9.0.0.1',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

-- drop index that is't used anymore
drop index fd.purge_pipeline_release_key_x1;

UPDATE fd.property_key_definition
SET
    property_key_sub_datatype = 'Long'
WHERE
    property_key_sub_datatype IS NULL
    AND property_key_datatype = 'Long';

-- Dashboard Group changed to Dashboard - Start
UPDATE fd.property_key
SET
    property_value_small = replace(
        property_value_small, ' Group', ''
    )
WHERE
    property_definition_id IN (
        SELECT
            property_definition_id
        FROM
            fd.property_key_definition
        WHERE
            property_key_name IN ( 'FDOTBI_DISCOVER_SUB_ITEMS', 'FDOAC_DISCOVER_SUB_ITEMS')
    )
    AND property_value_small IS NOT NULL;
-- Dashboard Group changed to Dashboard - End

-- FLEXDEPLOY-12524
UPDATE FD.PROPERTY_KEY_DEFINITION
SET PROPERTY_KEY_NAME = 'FDPBI_TGT_ACCOUNT_CODE'
WHERE PROPERTY_KEY_NAME = 'FDPBI_ACCOUNT_CODE';

--FLEXDEPLOY-13627
CREATE INDEX FDIX823 ON fd.workflow_execution (start_time desc) WHERE (parent_workflow_execution_id IS NULL);

-- FLEXDEPLOY-13503
CREATE OR REPLACE VIEW fd.VOBJECTPERMISSION AS
    SELECT
        ug.user_id,
        p.object_id,
        p.object_type,
        p.action_type
    FROM
        fd.fd_user_group ug
        INNER JOIN fd.fd_group_permission gp ON ug.group_id = gp.group_id
        INNER JOIN fd.fd_permission       p ON gp.permission_id = p.permission_id
        where (p.for_object_type is null or p.for_object_type='FOLDER' or p.action_type = 'CREATESNAPSHOT')
    UNION
    SELECT
        ug.user_id,
        p.object_id,
        p.object_type,
        p.action_type
    FROM
        fd.fd_user_ext_group ug
        INNER JOIN fd.fd_group_permission gp ON ug.group_id = gp.group_id
        INNER JOIN fd.fd_permission       p ON gp.permission_id = p.permission_id
        where (p.for_object_type is null or p.for_object_type='FOLDER' or p.action_type = 'CREATESNAPSHOT');
-- FLEXDEPLOY-13503

--leave at the end
commit;