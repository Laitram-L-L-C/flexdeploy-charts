insert into FD.FD_FLEXDEPLOY_VERSION values('9.0.0.4',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

alter table FD.PROPERTY_KEY_DEFINITION add PROVIDER_TYPE VARCHAR(255);
alter table FD.PROPERTY_KEY_DEFINITION add PROVIDER_NAME VARCHAR(255);

-- FLEXDEPLOY-13737 - Use OracleSaaS instead of OracleFSM - Start
update fd.account_provider set name = 'OracleSaaS' where name = 'OracleFSM' and vendor_name = 'Oracle';
update fd.instance set sub_group_code = 'OracleSaaS' where sub_group_code = 'OracleFSM' and group_code = 'CLOUD' and is_generic = 'N';
-- Update FDFSMACCT to FDORACLESAASACCT in key names
update fd.property_key_definition set property_key_name='FDORACLESAASACCT_AUTHTYPE' where property_key_name ='FDFSMACCT_AUTHTYPE';
update fd.property_key_definition set property_key_name='FDORACLESAASACCT_CERT_ALGORITHM' where property_key_name ='FDFSMACCT_CERT_ALGORITHM';
update fd.property_key_definition set property_key_name='FDORACLESAASACCT_CERT_ALIAS' where property_key_name ='FDFSMACCT_CERT_ALIAS';
update fd.property_key_definition set property_key_name='FDORACLESAASACCT_CERT_PASS' where property_key_name ='FDFSMACCT_CERT_PASS';
update fd.property_key_definition set property_key_name='FDORACLESAASACCT_CLIENT_ID' where property_key_name ='FDFSMACCT_CLIENT_ID';
update fd.property_key_definition set property_key_name='FDORACLESAASACCT_CLIENT_SECRET' where property_key_name ='FDFSMACCT_CLIENT_SECRET';
update fd.property_key_definition set property_key_name='FDORACLESAASACCT_IDENTITY_BASE_URI' where property_key_name ='FDFSMACCT_IDENTITY_BASE_URI';
update fd.property_key_definition set property_key_name='FDORACLESAASACCT_INSTANCE_URL' where property_key_name ='FDFSMACCT_INSTANCE_URL';
update fd.property_key_definition set property_key_name='FDORACLESAASACCT_KEYSTORE_PASS' where property_key_name ='FDFSMACCT_KEYSTORE_PASS';
update fd.property_key_definition set property_key_name='FDORACLESAASACCT_KEYSTORE_PATH' where property_key_name ='FDFSMACCT_KEYSTORE_PATH';
update fd.property_key_definition set property_key_name='FDORACLESAASACCT_PASSWORD' where property_key_name ='FDFSMACCT_PASSWORD';
update fd.property_key_definition set property_key_name='FDORACLESAASACCT_SCOPE' where property_key_name ='FDFSMACCT_SCOPE';
update fd.property_key_definition set property_key_name='FDORACLESAASACCT_USERNAME' where property_key_name ='FDFSMACCT_USERNAME';
commit;
-- FLEXDEPLOY-13737 - End

--FLEXDEPLOY-14221
DROP VIEW IF EXISTS FD.VRPTENVPROJSTAT;

CREATE OR REPLACE VIEW FD.VRPTENVPROJSTAT as
SELECT we.workflow_execution_id,
    p.folder_id,
    p.project_id,
    p.project_name,
    pv.project_version_name,
    pv.scm_revision,
    w.workflow_type,
    w.workflow_id,
    w.workflow_name,
    wv.workflow_version,
    pv.all_files_requested,
    e.environment_id,
    e.environment_name,
    i.instance_id,
    i.instance_name,
    we.execution_status,
    pw.project_workflow_type,
    we.start_time,
    we.end_time,
    wr.created_by AS requested_by,
    wr.created_on AS requested_on,
    wr.flex_field_1,
    wr.flex_field_2,
    wr.flex_field_3,
    wr.flex_field_4,
    wr.flex_field_5,
    wr.flex_field_6,
    wr.flex_field_7,
    wr.flex_field_8,
    wr.flex_field_9,
    wr.flex_field_10,
    pv.flex_field_1 AS build_flex_field1,
    pv.flex_field_2 AS build_flex_field2,
    pv.flex_field_3 AS build_flex_field3,
    pv.flex_field_4 AS build_flex_field4,
    pv.flex_field_5 AS build_flex_field5,
    pv.flex_field_6 AS build_flex_field6,
    pv.flex_field_7 AS build_flex_field7,
    pv.flex_field_8 AS build_flex_field8,
    pv.flex_field_9 AS build_flex_field9,
    pv.flex_field_10 AS build_flex_field10,
    NULL AS package_name,
    NULL AS package_created_by,
    NULL AS package_created_on,
    NULL AS package_updated_by,
    NULL AS package_updated_on,
    '' AS object_path,
    '' AS object_type,
    '' AS sub_component_name,
    '' AS sub_component_type,
    p.partial_deployments,
    f.folder_name,
    wr.rel_definition_id,
    wr.rel_snapshot_id,
    rd.rel_name,
    rd.rel_status,
    pd.name AS pipeline_name,
    rs.rel_snapshot,
    rs.created_by AS snapshot_submitted_by,
    wr.workflow_request_id,
    wr.pipeline_stage_exec_id,
    ( SELECT string_agg(wi.work_item_number, ', ' ORDER BY (wi.work_item_number)) AS string_agg
           FROM fd.workflow_execution_work_item exe_wi,
            fd.work_item wi
          WHERE exe_wi.workflow_execution_id = we.workflow_execution_id AND wi.work_item_id = exe_wi.work_item_id) AS work_item_ids,
    ( SELECT string_agg(ticket.ticket_number, ', ' ORDER BY (ticket.ticket_number)) AS string_agg
           FROM fd.workflow_request_ticket wrt,
            fd.cms_ticket ticket
          WHERE wrt.cms_ticket_id = ticket.cms_ticket_id AND wrt.workflow_request_id = wr.workflow_request_id) AS external_ticket,
    pv.project_version_id,
    ( SELECT string_agg(ht.action_by, ', ' ORDER BY (ht.action_by)) AS string_agg
           FROM fd.human_task ht
          WHERE (ht.workflow_request_id = wr.workflow_request_id OR ht.pipeline_stage_exec_id = wr.pipeline_stage_exec_id AND ht.pipeline_stage_gate_id IS NOT NULL OR ht.workflow_execution_id = we.predeploy_workflow_exec_id) AND ht.task_status = 'APPROVED' AND (ht.task_type in ('PRE_DEPLOY_REVIEW', 'APPROVAL'))) AS approved_by_usernames,
    ps.stream_name,
    wr.force_deploy AS force,
    wr.folder_request_id,
    NULL AS pkg_status,
    NULL AS commit_user
   FROM fd.project_wf_current_status pwcs
   join fd.project p
      on p.project_id = pwcs.project_id
     and p.partial_deployments = 'N'
   join fd.workflow_execution we on we.workflow_execution_id = pwcs.workflow_execution_id
    join fd.project_version pv on pv.project_version_id = we.project_version_id
    join fd.environment e on e.environment_id = pwcs.environment_id
    join fd.project_workflow pw
        on pw.project_workflow_id = we.project_workflow_id
       AND pw.project_workflow_type IN ('DEPLOY', 'SYNCSTATE')
    join fd.instance i on i.instance_id = pwcs.instance_id 
    join fd.workflow_request wr on wr.workflow_request_id = we.workflow_request_id
    Join fd.folder f on p.folder_id = f.folder_id
    join fd.workflow_version wv on wv.workflow_version_id = we.workflow_version_id
    join fd.workflow w on w.workflow_id = we.workflow_id
    LEFT JOIN fd.rel_definition rd ON wr.rel_definition_id = rd.rel_definition_id
    LEFT JOIN fd.pipeline_definition pd ON rd.pipeline_definition_id = pd.pipeline_definition_id
    LEFT JOIN fd.rel_snapshot rs ON wr.rel_snapshot_id = rs.rel_snapshot_id
    LEFT JOIN fd.project_stream ps ON pv.project_stream_id = ps.project_stream_id
UNION ALL
 SELECT we.workflow_execution_id,
    p.folder_id,
    p.project_id,
    p.project_name,
    pv.project_version_name,
    pkgobj.scm_revision,
    w.workflow_type,
    w.workflow_id,
    w.workflow_name,
    wv.workflow_version,
    pv.all_files_requested,
    e.environment_id,
    e.environment_name,
    i.instance_id,
    i.instance_name,
    we.execution_status,
    pw.project_workflow_type,
    we.start_time,
    we.end_time,
    wr.created_by AS requested_by,
    wr.created_on AS requested_on,
    wr.flex_field_1,
    wr.flex_field_2,
    wr.flex_field_3,
    wr.flex_field_4,
    wr.flex_field_5,
    wr.flex_field_6,
    wr.flex_field_7,
    wr.flex_field_8,
    wr.flex_field_9,
    wr.flex_field_10,
    pv.flex_field_1 AS build_flex_field1,
    pv.flex_field_2 AS build_flex_field2,
    pv.flex_field_3 AS build_flex_field3,
    pv.flex_field_4 AS build_flex_field4,
    pv.flex_field_5 AS build_flex_field5,
    pv.flex_field_6 AS build_flex_field6,
    pv.flex_field_7 AS build_flex_field7,
    pv.flex_field_8 AS build_flex_field8,
    pv.flex_field_9 AS build_flex_field9,
    pv.flex_field_10 AS build_flex_field10,
    pv.package_name,
    pp.created_by AS package_created_by,
    pp.created_on AS package_created_on,
    pp.updated_by AS package_updated_by,
    pp.updated_on AS package_updated_on,
    prjobj.object_path,
    objtyp.object_type_code AS object_type,
    prjobj.sub_component_name,
    prjobj.sub_component_type,
    p.partial_deployments,
    f.folder_name,
    wr.rel_definition_id,
    wr.rel_snapshot_id,
    rd.rel_name,
    rd.rel_status,
    pd.name AS pipeline_name,
    rs.rel_snapshot,
    rs.created_by AS snapshot_submitted_by,
    wr.workflow_request_id,
    wr.pipeline_stage_exec_id,
    ( SELECT string_agg(wi.work_item_number, ', ' ORDER BY (wi.work_item_number)) AS string_agg
           FROM fd.workflow_execution_work_item exe_wi,
            fd.work_item wi
          WHERE exe_wi.workflow_execution_id = we.workflow_execution_id AND wi.work_item_id = exe_wi.work_item_id) AS work_item_ids,
    ( SELECT string_agg(ticket.ticket_number, ', ' ORDER BY (ticket.ticket_number)) AS string_agg
           FROM fd.workflow_request_ticket wrt,
            fd.cms_ticket ticket
          WHERE wrt.cms_ticket_id = ticket.cms_ticket_id AND wrt.workflow_request_id = wr.workflow_request_id) AS external_ticket,
    pv.project_version_id,
    ( SELECT string_agg(ht.action_by, ', ' ORDER BY (ht.action_by)) AS string_agg
           FROM fd.human_task ht
          WHERE (ht.workflow_request_id = wr.workflow_request_id OR ht.pipeline_stage_exec_id = wr.pipeline_stage_exec_id AND ht.pipeline_stage_gate_id IS NOT NULL OR ht.workflow_execution_id = we.predeploy_workflow_exec_id) AND ht.task_status = 'APPROVED' AND ht.task_type in ('PRE_DEPLOY_REVIEW', 'APPROVAL')) AS approved_by_usernames,
    ps.stream_name,
    wr.force_deploy AS force,
    wr.folder_request_id,
    ( SELECT string_agg(pkgexec.execution_status, ',' ORDER BY (pkgexec.execution_status)) AS string_agg
           FROM fd.plugin_execution pexec,
            fd.package_object_execution pkgexec
          WHERE pkgobj.package_object_id IS NOT NULL 
          AND pkgexec.package_object_id = pkgobj.package_object_id
          AND pkgexec.plugin_execution_id = pexec.plugin_execution_id
          AND pexec.workflow_execution_id = pkjobjcs.workflow_execution_id
          AND w.workflow_type in ('DEPLOY', 'SYNCSTATE')) AS pkg_status,
    por.commit_user
   FROM fd.package_obj_current_status pkjobjcs
    join fd.workflow_execution we on we.workflow_execution_id = pkjobjcs.workflow_execution_id
    join fd.project p 
       on p.project_id = we.project_id 
      AND p.partial_deployments = 'Y'
    join fd.folder f on p.folder_id = f.folder_id
    join fd.project_version pv
	  on pv.project_version_id = we.project_version_id
	  and p.project_id = pv.project_id
    join fd.environment e on e.environment_id = we.environment_id
    join fd.instance i on i.instance_id = we.instance_id
    join fd.project_workflow pw 
      on pw.project_workflow_id = we.project_workflow_id 
     and pw.project_workflow_type in ('DEPLOY', 'SYNCSTATE')
    join fd.workflow_request wr on wr.workflow_request_id = we.workflow_request_id
    join fd.package_object pkgobj
      on pkgobj.project_object_id = pkjobjcs.project_object_id
     AND pv.project_version_id = pkgobj.project_version_id
    join fd.project_object prjobj on pkgobj.project_object_id = prjobj.project_object_id
    join fd.object_type objtyp on prjobj.object_type_id = objtyp.object_type_id
    join fd.workflow_version wv on wv.workflow_version_id = we.workflow_version_id
    join fd.workflow w on w.workflow_id = we.workflow_id
     LEFT JOIN fd.project_package pp
            ON pv.project_id = pp.project_id
	       AND pv.package_name = pp.package_name
     LEFT JOIN fd.project_stream ps ON ps.project_stream_id = pv.project_stream_id
     LEFT JOIN fd.rel_definition rd ON wr.rel_definition_id = rd.rel_definition_id
     LEFT JOIN fd.pipeline_definition pd ON rd.pipeline_definition_id = pd.pipeline_definition_id
     LEFT JOIN fd.rel_snapshot rs ON wr.rel_snapshot_id = rs.rel_snapshot_id
     LEFT JOIN fd.project_object_revision por
	       ON por.project_object_id = pkgobj.project_object_id
	      AND por.scm_revision = pkgobj.scm_revision;


create index PACKAGE_OBJECT_EXECUTION_STATUS on fd.package_object_execution(package_object_id,plugin_execution_id,execution_status);

grant all privileges on FD.VRPTENVPROJSTAT to FD_ADMIN;


--FLEXDEPLOY-14221

alter table FD.FD_OAUTH_TOKEN add AUTHORIZED_BY VARCHAR(128);

-- FLEXDEPLOY - 14230 - Start
update fd.credential set credential_name = replace(credential_name, 'Private key - /', 'SSH Key - /')
where credential_scope = 'ENDPOINT' and credential_type = 'SSH_KEY' and credential_name like 'Private key -%' and created_by = 'autoupload';
-- FLEXDEPLOY - 14230 - End


commit;