set define off;
set echo on;

-- 6.5.0.9
insert into FD.FD_FLEXDEPLOY_VERSION values('6.5.0.9',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

-- HTTPS Agent Endpoint turn off hostname verification - start
ALTER TABLE FD.ENDPOINT ADD DISABLE_HOSTNAME_VERIFICATION CHAR(1);
-- HTTPS Agent Endpoint turn off hostname verification - end

-- leave at the end