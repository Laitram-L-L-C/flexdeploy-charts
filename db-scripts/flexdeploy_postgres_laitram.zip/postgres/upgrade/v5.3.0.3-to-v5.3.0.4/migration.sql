-- 5.3.0.4
insert into FD.FD_FLEXDEPLOY_VERSION values('5.3.0.4',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

CREATE OR REPLACE VIEW FD.VRPTENVDTSRCH AS
SELECT  
  WE.WORKFLOW_EXECUTION_ID,  
  P.PROJECT_ID,  
  P.FOLDER_ID,  
  P.PROJECT_NAME,  
  PV.PROJECT_VERSION_NAME,  
  PV.SCM_REVISION SCM_REVISION,  
  NULL PO_SCM_REVISION,  
  W.WORKFLOW_TYPE,  
  W.WORKFLOW_ID,  
  WV.WORKFLOW_VERSION,  
  E.ENVIRONMENT_NAME,  
  WE.ENVIRONMENT_ID,  
  I.INSTANCE_NAME,  
  WE.INSTANCE_ID,  
  WE.EXECUTION_STATUS,  
  WR.CREATED_ON REQUESTED_ON,  
  WR.CREATED_BY REQUESTED_BY,  
  WE.START_TIME,  
  WE.END_TIME,  
  WR.FLEX_FIELD_1,  
  WR.FLEX_FIELD_2,  
  WR.FLEX_FIELD_3,  
  WR.FLEX_FIELD_4,  
  WR.FLEX_FIELD_5,  
  WR.FLEX_FIELD_6,  
  WR.FLEX_FIELD_7,  
  WR.FLEX_FIELD_8,  
  WR.FLEX_FIELD_9,  
  WR.FLEX_FIELD_10,  
  PV.FLEX_FIELD_1 BUILD_FLEX_FIELD1,  
  PV.FLEX_FIELD_2 BUILD_FLEX_FIELD2,  
  PV.FLEX_FIELD_3 BUILD_FLEX_FIELD3,  
  PV.FLEX_FIELD_4 BUILD_FLEX_FIELD4,  
  PV.FLEX_FIELD_5 BUILD_FLEX_FIELD5,  
  PV.FLEX_FIELD_6 BUILD_FLEX_FIELD6,  
  PV.FLEX_FIELD_7 BUILD_FLEX_FIELD7,  
  PV.FLEX_FIELD_8 BUILD_FLEX_FIELD8,  
  PV.FLEX_FIELD_9 BUILD_FLEX_FIELD9,  
  PV.FLEX_FIELD_10 BUILD_FLEX_FIELD10,  
  PV.PACKAGE_NAME,  
  NULL OBJECT_PATH,  
  P.PARTIAL_DEPLOYMENTS,  
  PV.ALL_FILES_REQUESTED,  
  WR.REL_DEFINITION_ID,  
  WR.REL_SNAPSHOT_ID,  
  RD.REL_NAME,     
  RS.REL_SNAPSHOT,   
  WR.PIPELINE_STAGE_EXEC_ID as STAGE_EXEC_ID,  
  WR.WORKFLOW_REQUEST_ID,  
  WR.FOLDER_REQUEST_ID,  
  NULL PKG_STATUS, 
  (SELECT string_agg(ISSUE.ISSUE_NUMBER, ', ' ORDER BY ISSUE.ISSUE_NUMBER)  
   FROM FD.PROJECT_VERSION_ITS_ISSUE ISSUE WHERE ISSUE.PROJECT_VERSION_ID =  PV.PROJECT_VERSION_ID) as ITS_TICKET_IDS,  
  (SELECT string_agg(ISSUE_NUMBER, ', ' ORDER BY ISSUE_NUMBER) FROM FD.WORKFLOW_REQUEST_CMS_ISSUE WHERE WORKFLOW_REQUEST_ID=WR.WORKFLOW_REQUEST_ID) CMS_TICKET_IDS,
  PS.STREAM_NAME  
FROM   
  FD.WORKFLOW_EXECUTION WE,  
  FD.PROJECT P,  
  FD.PROJECT_VERSION PV
  left outer join FD.PROJECT_STREAM PS on PS.PROJECT_STREAM_ID = PV.PROJECT_STREAM_ID,  
  FD.PROJECT_WORKFLOW PW,  
  FD.ENVIRONMENT E,  
  FD.INSTANCE I,  
  FD.WORKFLOW_VERSION WV,  
  FD.WORKFLOW W,  
  FD.WORKFLOW_REQUEST WR
  left outer join FD.REL_DEFINITION RD on WR.REL_DEFINITION_ID = RD.REL_DEFINITION_ID 
  left outer join FD.REL_SNAPSHOT RS  on WR.REL_SNAPSHOT_ID = RS.REL_SNAPSHOT_ID  
WHERE P.PROJECT_ID = WE.PROJECT_ID  
AND PW.PROJECT_WORKFLOW_ID = WE.PROJECT_WORKFLOW_ID  
AND E.ENVIRONMENT_ID = WE.ENVIRONMENT_ID  
AND I.INSTANCE_ID = WE.INSTANCE_ID  
AND PV.PROJECT_VERSION_ID = WE.PROJECT_VERSION_ID  
AND WV.WORKFLOW_VERSION_ID = WE.WORKFLOW_VERSION_ID  
AND W.WORKFLOW_ID = PW.WORKFLOW_ID  
AND WR.WORKFLOW_REQUEST_ID = WE.WORKFLOW_REQUEST_ID  
AND WE.PARENT_WORKFLOW_EXECUTION_ID IS NULL;

CREATE OR REPLACE VIEW FD.VRPTENVPROJSTAT as
SELECT
    we.workflow_execution_id,
    p.folder_id,
    p.project_id,
    p.project_name,
    pv.project_version_name,
    pv.scm_revision    scm_revision,
    pv.all_files_requested,
    e.environment_id,
    e.environment_name,
    i.instance_id,
    i.instance_name,
    we.execution_status,
    pw.project_workflow_type,
    we.start_time,
    we.end_time,
    wr.created_by      requested_by,
    wr.created_on      requested_on,
    wr.flex_field_1,
    wr.flex_field_2,
    wr.flex_field_3,
    wr.flex_field_4,
    wr.flex_field_5,
    wr.flex_field_6,
    wr.flex_field_7,
    wr.flex_field_8,
    wr.flex_field_9,
    wr.flex_field_10,
    pv.flex_field_1    build_flex_field1,
    pv.flex_field_2    build_flex_field2,
    pv.flex_field_3    build_flex_field3,
    pv.flex_field_4    build_flex_field4,
    pv.flex_field_5    build_flex_field5,
    pv.flex_field_6    build_flex_field6,
    pv.flex_field_7    build_flex_field7,
    pv.flex_field_8    build_flex_field8,
    pv.flex_field_9    build_flex_field9,
    pv.flex_field_10   build_flex_field10,
    NULL package_name,
    '' object_path,
    p.partial_deployments,
    f.folder_name,
    wr.rel_definition_id,
    rd.rel_name,
    rs.rel_snapshot,
    wr.workflow_request_id,
    wr.folder_request_id,
    wr.pipeline_stage_exec_id,
    (
        SELECT
            string_agg(ISSUE_NUMBER, ', ' ORDER BY ISSUE_NUMBER)
        FROM 
            FD.WORKFLOW_REQUEST_CMS_ISSUE 
        WHERE 
            WORKFLOW_REQUEST_ID=WR.WORKFLOW_REQUEST_ID
    ) external_ticket,
    pv.project_version_id,
    ps.stream_name
FROM
    FD.WORKFLOW_EXECUTION we,
    FD.PROJECT p,
    FD.PROJECT_VERSION pv
    left outer join FD.PROJECT_STREAM ps on pv.project_stream_id = ps.project_stream_id,
    FD.ENVIRONMENT e,
    FD.PROJECT_WORKFLOW pw,
    FD.INSTANCE i,
    FD.PROJECT_WF_CURRENT_STATUS pwcs, FD.WORKFLOW_REQUEST wr
    LEFT OUTER JOIN FD.REL_DEFINITION rd ON wr.rel_definition_id = rd.rel_definition_id
    LEFT OUTER JOIN FD.REL_SNAPSHOT rs ON wr.rel_snapshot_id = rs.rel_snapshot_id,
    FD.FOLDER f
WHERE
    p.project_id = we.project_id
    AND p.folder_id = f.folder_id
    AND pv.project_version_id = we.project_version_id
    AND e.environment_id = we.environment_id
    AND i.instance_id = we.instance_id
    AND pw.project_workflow_id = we.project_workflow_id
    AND p.partial_deployments = 'N'
    AND pw.project_workflow_type = 'DEPLOY'
    AND wr.workflow_request_id = we.workflow_request_id
    AND we.workflow_execution_id = pwcs.workflow_execution_id
UNION ALL
SELECT
    we.workflow_execution_id,
    p.folder_id,
    p.project_id,
    p.project_name,
    pv.project_version_name,
    pkgobj.scm_revision   scm_revision,
    pv.all_files_requested,
    e.environment_id,
    e.environment_name,
    i.instance_id,
    i.instance_name,
    we.execution_status,
    pw.project_workflow_type,
    we.start_time,
    we.end_time,
    wr.created_by         requested_by,
    wr.created_on         requested_on,
    wr.flex_field_1,
    wr.flex_field_2,
    wr.flex_field_3,
    wr.flex_field_4,
    wr.flex_field_5,
    wr.flex_field_6,
    wr.flex_field_7,
    wr.flex_field_8,
    wr.flex_field_9,
    wr.flex_field_10,
    pv.flex_field_1       build_flex_field1,
    pv.flex_field_2       build_flex_field2,
    pv.flex_field_3       build_flex_field3,
    pv.flex_field_4       build_flex_field4,
    pv.flex_field_5       build_flex_field5,
    pv.flex_field_6       build_flex_field6,
    pv.flex_field_7       build_flex_field7,
    pv.flex_field_8       build_flex_field8,
    pv.flex_field_9       build_flex_field9,
    pv.flex_field_10      build_flex_field10,
    pv.package_name       package_name,
    prjobj.object_path    object_path,
    p.partial_deployments,
    f.folder_name,
    wr.rel_definition_id,
    rd.rel_name,
    rs.rel_snapshot,
    wr.workflow_request_id,
    wr.folder_request_id,
    wr.pipeline_stage_exec_id,
    (
        SELECT
            string_agg(ISSUE_NUMBER, ', ' ORDER BY ISSUE_NUMBER)
        FROM 
            FD.WORKFLOW_REQUEST_CMS_ISSUE 
        WHERE 
            WORKFLOW_REQUEST_ID=WR.WORKFLOW_REQUEST_ID
    ) external_ticket,
    pv.project_version_id,
    ps.stream_name
FROM
    FD.WORKFLOW_EXECUTION we,
    FD.PROJECT p,
    FD.PROJECT_VERSION pv
    left outer join FD.PROJECT_STREAM ps on pv.project_stream_id = ps.project_stream_id,
    FD.ENVIRONMENT e,
    FD.PROJECT_WORKFLOW pw,
    FD.INSTANCE i,
    FD.PACKAGE_OBJ_CURRENT_STATUS pkjobjcs, FD.WORKFLOW_REQUEST wr
    LEFT OUTER JOIN FD.REL_DEFINITION rd ON wr.rel_definition_id = rd.rel_definition_id
    LEFT OUTER JOIN FD.REL_SNAPSHOT rs ON wr.rel_snapshot_id = rs.rel_snapshot_id,
    FD.PACKAGE_OBJECT pkgobj,
    FD.PROJECT_OBJECT prjobj,
    FD.FOLDER f
WHERE
    p.project_id = we.project_id
    AND p.folder_id = f.folder_id
    AND pv.project_version_id = we.project_version_id
    AND e.environment_id = we.environment_id
    AND i.instance_id = we.instance_id
    AND pw.project_workflow_id = we.project_workflow_id
    AND p.partial_deployments = 'Y'
    AND pw.project_workflow_type = 'DEPLOY'
    AND wr.workflow_request_id = we.workflow_request_id
    AND we.workflow_execution_id = pkjobjcs.workflow_execution_id
    AND p.project_id = pv.project_id
    AND pkgobj.project_object_id = pkjobjcs.project_object_id
    AND pv.project_version_id = pkgobj.project_version_id
    AND pkgobj.project_object_id = prjobj.project_object_id;

ALTER TABLE FD.PROJECT_PACKAGE
ADD TEST_LEVEL VARCHAR(128);
UPDATE FD.PROJECT_PACKAGE SET TEST_LEVEL = 'NoTestRun';

ALTER TABLE FD.PROJECT_PACKAGE
ADD TESTS VARCHAR(255);

COMMIT;