-- 5.7.0.1
insert into FD.FD_FLEXDEPLOY_VERSION values('5.7.0.1',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

-- Project Package - start

ALTER TABLE FD.PROJECT_PACKAGE ALTER TESTS TYPE VARCHAR(4000);

-- Project Package - end

COMMIT;