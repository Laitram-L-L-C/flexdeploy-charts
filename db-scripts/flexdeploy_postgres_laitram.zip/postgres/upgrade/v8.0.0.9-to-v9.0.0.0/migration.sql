insert into FD.FD_FLEXDEPLOY_VERSION values('9.0.0.0',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

--scm commit - start
ALTER TABLE FD.SCM_COMMIT ADD ADDED_LINES NUMERIC(8, 0);
ALTER TABLE FD.SCM_COMMIT ADD REMOVED_LINES NUMERIC(8, 0);
--scm commit - end

--credential - start
ALTER TABLE FD.CREDENTIAL ADD CREDENTIAL_TYPE VARCHAR(50);
UPDATE FD.CREDENTIAL SET CREDENTIAL_TYPE = 'SECRET_TEXT';
ALTER TABLE FD.CREDENTIAL ALTER COLUMN CREDENTIAL_TYPE SET NOT NULL;
--credential - end

--credential input - start
ALTER TABLE FD.CREDENTIAL_INPUT ADD FILE_NAME VARCHAR(255);
ALTER TABLE FD.CREDENTIAL_INPUT ALTER COLUMN INPUT_VALUE TYPE TEXT;
--credential input - end


-- standard project rollback - start
ALTER TABLE FD.WORKFLOW_REQUEST ADD IS_ROLLBACK CHAR(1);
UPDATE FD.WORKFLOW_REQUEST SET IS_ROLLBACK = 'N';
ALTER TABLE FD.WORKFLOW_REQUEST ALTER COLUMN IS_ROLLBACK SET NOT NULL;

ALTER TABLE FD.WORKFLOW_EXECUTION ADD ROLLED_BACK_WF_EXEC_ID NUMERIC(20, 0);
-- standard project rollback - end

-- workflow request notes - start
ALTER TABLE FD.WORKFLOW_REQUEST ADD REQUEST_NOTES VARCHAR(255);
-- workflow request notes - end

-- db properties data - start
ALTER TABLE FF.DB_PROPERTIES ADD DB_PROPERTIES_VALUE_LARGE TEXT;
ALTER TABLE FF.DB_PROPERTIES ADD DB_PROPERTIES_VALUE_SMALL VARCHAR(4000);
ALTER TABLE FF.DB_PROPERTIES ADD CREDENTIAL_ID NUMERIC(20,0);
UPDATE FF.DB_PROPERTIES DBP SET DB_PROPERTIES_VALUE_LARGE = (SELECT string_agg(DB_PROPERTIES_VALUE,'' ORDER BY SEQUENCE_NUMBER) FROM FF.DB_PROPERTIES_DATA WHERE DB_PROPERTIES_ID = DBP.DB_PROPERTIES_ID);

ALTER TABLE FF.DB_PROPERTIES_DATA
DROP CONSTRAINT IF EXISTS DB_PROPERTIES_DATA;
alter table FF.DB_PROPERTIES_DATA rename to DB_PROPERTIES_DATA_OLD;
-- db properties data - end

-- oauth updates
alter table FD.FD_OAUTH_TOKEN add USER_ID NUMERIC(20);

ALTER TABLE FD.FD_OAUTH_TOKEN
ADD CONSTRAINT FD_OAUTH_TOKEN_FK1 FOREIGN KEY
(
  USER_ID
)
REFERENCES FD.FD_USER
(
  USER_ID
);

ALTER TABLE FD.FD_OAUTH_TOKEN
DROP CONSTRAINT IF EXISTS FD_OAUTH_TOKEN_UK1;

DROP INDEX IF EXISTS FD.FD_OAUTH_TOKEN_UK1;

ALTER TABLE FD.FD_OAUTH_TOKEN
ADD CONSTRAINT FD_OAUTH_TOKEN_UK1 UNIQUE 
(
  FD_OAUTH_TOKEN_PROVIDER 
, TOKEN_TYPE 
, FD_OAUTH_CLIENT_ID 
, USER_ID
)
;

CREATE TABLE FD.FD_OAUTH_APPLICATION_DEF 
(
  FD_OAUTH_APPLICATION_DEF_ID NUMERIC(20, 0) NOT NULL 
, NAME VARCHAR(255) NOT NULL 
, DESCRIPTION VARCHAR(4000) NOT NULL 
, ICON VARCHAR(4000) NOT NULL 
, PROVIDER VARCHAR(50) NOT NULL 
, SCOPE VARCHAR(50) NOT NULL 
, FUNCTIONAL_AREA VARCHAR(255) NOT NULL 
, INSTRUCTIONS TEXT
, CREATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP NOT NULL 
, CREATED_BY VARCHAR(128) NOT NULL 
, UPDATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP NOT NULL 
, UPDATED_BY VARCHAR(128) NOT NULL 
, VERSION_NUMBER NUMERIC(8, 0) 
, CONSTRAINT FD_OAUTH_APPLICATION_DEF_PK PRIMARY KEY 
  (
    FD_OAUTH_APPLICATION_DEF_ID 
  )
);

CREATE TABLE FD.FD_OAUTH_APPLICATION 
(
  FD_OAUTH_APPLICATION_ID NUMERIC(20, 0) NOT NULL 
, NAME VARCHAR(255) NOT NULL 
, IS_READONLY CHAR DEFAULT 'N' NOT NULL 
, IS_ENABLED CHAR DEFAULT 'Y' NOT NULL 
, OAUTH_APPLICATION_DEF_ID NUMERIC(20) NOT NULL 
, CLIENT_ID VARCHAR(4000) NOT NULL 
, CLIENT_SECRET_CREDENTIAL NUMERIC(20) 
, CREATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP NOT NULL 
, CREATED_BY VARCHAR(128) NOT NULL 
, UPDATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP NOT NULL 
, UPDATED_BY VARCHAR(128) NOT NULL 
, VERSION_NUMBER NUMERIC(8, 0) 
, CONSTRAINT FD_OAUTH_APPLICATION_PK PRIMARY KEY 
  (
    FD_OAUTH_APPLICATION_ID 
  )
);

CREATE TABLE FD.FD_OAUTH_APPLICATION_PROPERTY 
(
  PROPERTY_ID NUMERIC(20, 0) NOT NULL 
, APPLICATION_ID NUMERIC(20, 0) NOT NULL 
, PROPERTY_DEFINITION_ID NUMERIC(20) NOT NULL 
, VALUE VARCHAR(4000) 
, CREDENTIAL_ID NUMERIC(20) 
, CREATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP NOT NULL 
, CREATED_BY VARCHAR(128) NOT NULL 
, UPDATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP NOT NULL 
, UPDATED_BY VARCHAR(128) NOT NULL 
, VERSION_NUMBER NUMERIC(8, 0) 
, CONSTRAINT FD_OAUTH_APPLICATION_PROPE_PK PRIMARY KEY 
  (
    PROPERTY_ID 
  ) 
);

ALTER TABLE FD.FD_OAUTH_APPLICATION
ADD CONSTRAINT FD_OAUTH_APPLICATION_UK1 UNIQUE 
(
  NAME 
)
;

ALTER TABLE FD.FD_OAUTH_APPLICATION_DEF
ADD CONSTRAINT FD_OAUTH_APPLICATION_DEF_UK1 UNIQUE 
(
  NAME 
)
;

ALTER TABLE FD.FD_OAUTH_APPLICATION_DEF
ADD CONSTRAINT FD_OAUTH_APPLICATION_DEF_UK2 UNIQUE 
(
  PROVIDER 
)
;

ALTER TABLE FD.FD_OAUTH_APPLICATION
ADD CONSTRAINT FD_OAUTH_APPLICATION_FK1 FOREIGN KEY
(
  OAUTH_APPLICATION_DEF_ID 
)
REFERENCES FD.FD_OAUTH_APPLICATION_DEF
(
  FD_OAUTH_APPLICATION_DEF_ID 
)
;

ALTER TABLE FD.FD_OAUTH_APPLICATION_PROPERTY
ADD CONSTRAINT FD_OAUTH_APPLICATION_PROP_FK1 FOREIGN KEY
(
  CREDENTIAL_ID 
)
REFERENCES FD.CREDENTIAL
(
  CREDENTIAL_ID 
)
;

ALTER TABLE FD.FD_OAUTH_APPLICATION_PROPERTY
ADD CONSTRAINT FD_OAUTH_APPLICATION_PROP_FK2 FOREIGN KEY
(
  PROPERTY_DEFINITION_ID 
)
REFERENCES FD.PROPERTY_KEY_DEFINITION
(
  PROPERTY_DEFINITION_ID 
)
;

ALTER TABLE FD.FD_OAUTH_APPLICATION
ADD CONSTRAINT FD_OAUTH_APPLICATION_FK2 FOREIGN KEY
(
  CLIENT_SECRET_CREDENTIAL 
)
REFERENCES FD.CREDENTIAL
(
  CREDENTIAL_ID 
)
;

ALTER TABLE FD.FD_OAUTH_APPLICATION
ADD CONSTRAINT FD_OAUTH_APPLICATION_UK2 UNIQUE 
(
  CLIENT_ID 
, OAUTH_APPLICATION_DEF_ID 
)
;

grant all privileges on FD.FD_OAUTH_APPLICATION_DEF to FD_ADMIN;
grant all privileges on FD.FD_OAUTH_APPLICATION to FD_ADMIN;
grant all privileges on FD.FD_OAUTH_APPLICATION_PROPERTY  to FD_ADMIN;
-- oauth updates - end

-- work item validation gate - start
alter table FD.PIPELINE_STAGE_GATE_EXEC add EXEC_DATA TEXT;
alter table FD.PIPELINE_STAGE_STEP_EXEC add EXEC_DATA TEXT;
-- work item validation gate - end

-- endpoint - start
ALTER TABLE FD.ENDPOINT ADD COLUMN PRIVATE_KEY_CREDENTIAL_ID NUMERIC(20,0);

ALTER TABLE FD.ENDPOINT
ADD CONSTRAINT ENDPOINT_FK3 FOREIGN KEY
(
 PRIVATE_KEY_CREDENTIAL_ID 
)
REFERENCES FD.CREDENTIAL
(
 CREDENTIAL_ID 
)
;
-- endpoint - end

-- package-based rollback - start
ALTER TABLE FD.PACKAGE_OBJECT ADD FROM_BACKUP_VERSION_ID NUMERIC(20);
ALTER TABLE FD.PACKAGE_OBJECT ADD ROLLS_BACK_PROJECT_OBJECT_ID NUMERIC(20);
ALTER TABLE FD.PACKAGE_OBJECT
ADD CONSTRAINT PROJECT_OBJECT_ROLLBACK FOREIGN KEY
(
  ROLLS_BACK_PROJECT_OBJECT_ID 
)
REFERENCES FD.PROJECT_OBJECT
(
  PROJECT_OBJECT_ID 
)
;
-- package-based rollback - end
 
-- property key definition - start
ALTER TABLE FD.PROPERTY_KEY_DEFINITION ADD CREDENTIAL_TYPE VARCHAR(50);
-- property key definition - end

-- alter report uk start
ALTER TABLE FD.WORKFLOW_EXECUTION_REPORT
DROP CONSTRAINT WORKFLOW_EXECUTION_REPORT_UK1;

DROP INDEX IF EXISTS FD.WORKFLOW_EXECUTION_REPORT_UK1;

CREATE UNIQUE INDEX WORKFLOW_EXECUTION_REPORT_UK1  
ON FD.WORKFLOW_EXECUTION_REPORT
(
  WORKFLOW_EXECUTION_ID 
, FILE_NAME 
, coalesce (CATEGORY ,'')
, coalesce (TYPE ,'') 
, coalesce (SUB_TYPE ,'')  
)
;

-- alter report uk end

-- groovy-libs
CREATE TABLE FD.GROOVY_LIBRARY
(
  GROOVY_LIBRARY_ID NUMERIC(20, 0) NOT NULL
, SCRIPT_KEY VARCHAR(50) NOT NULL
, DESCRIPTION VARCHAR(4000)
, SCRIPT_CONTENT TEXT NOT NULL
, CREATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP
, CREATED_BY VARCHAR(128) NOT NULL
, UPDATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP
, UPDATED_BY VARCHAR(128) NOT NULL
, VERSION_NUMBER NUMERIC(8, 0)
, CONSTRAINT GROOVY_LIBRARY_PK PRIMARY KEY
  (
    GROOVY_LIBRARY_ID
  )
);

ALTER TABLE FD.GROOVY_LIBRARY
ADD CONSTRAINT GROOVY_LIBRARY_UK1 UNIQUE
(
  SCRIPT_KEY
)
;

grant all privileges on FD.GROOVY_LIBRARY to FD_ADMIN;
-- groovy-libs --end

-- integration properties sub-datatype
UPDATE fd.property_key_definition
SET
    property_key_sub_datatype = 'TextField'
WHERE
    property_key_sub_datatype IS NULL
    AND property_key_datatype = 'String';

UPDATE fd.property_key_definition
SET
    property_key_sub_datatype = 'Long'
WHERE
    property_key_sub_datatype IS NULL
    AND property_key_datatype = 'Integer';

UPDATE fd.property_key_definition
SET
    property_key_sub_datatype = 'Boolean'
WHERE
    property_key_sub_datatype IS NULL
    AND property_key_datatype = 'Boolean';

UPDATE fd.property_key_definition
SET
    property_key_sub_datatype = 'Double'
WHERE
    property_key_sub_datatype IS NULL
    AND property_key_datatype = 'Double';

UPDATE fd.property_key_definition
SET
    property_key_sub_datatype = 'Directory'
WHERE
    property_key_sub_datatype = 'DIRECTORY';
-- integration properties sub-datatype --end

-- pipeline definition - start
ALTER TABLE FD.PIPELINE_DEFINITION ADD SECURITY_OVERRIDDEN CHAR(1) DEFAULT 'N';
UPDATE FD.PIPELINE_DEFINITION SET SECURITY_OVERRIDDEN = 'N';
-- pipeline definition - end

alter table FD.DEPLOY_APPROVAL add IS_ALL_TASKS_REQUIRED CHAR(1) DEFAULT 'Y';
alter table FD.HUMAN_TASK add IS_ALL_PROJECT_TASKS_REQUIRED CHAR(1);

-- request snapshot inputs

CREATE TABLE FD.WORKFLOW_REQUEST_DATA 
(
  WORKFLOW_REQUEST_ID NUMERIC(20, 0) NOT NULL 
, WFREQ_DATA_KEY VARCHAR(255) NOT NULL 
, WFREQ_DATA_VALUE VARCHAR(4000) 
, WFREQ_DATA_VALUE_LARGE TEXT 
, WFREQ_DATA_CATEGORY VARCHAR(50) NOT NULL 
, IS_ENCRYPTED CHAR(1) NOT NULL 
, CREATED_ON TIMESTAMP WITH TIME ZONE  DEFAULT CURRENT_TIMESTAMP NOT NULL 
, CREATED_BY VARCHAR(128) NOT NULL 
, CONSTRAINT WORKFLOW_REQUEST_REL_INPUT_PK PRIMARY KEY 
  (
    WORKFLOW_REQUEST_ID 
  , WFREQ_DATA_KEY 
  )
   
);

ALTER TABLE FD.WORKFLOW_REQUEST_DATA
ADD CONSTRAINT WORKFLOW_REQUEST_REL_INPU_FK1 FOREIGN KEY
(
  WORKFLOW_REQUEST_ID 
)
REFERENCES FD.WORKFLOW_REQUEST
(
  WORKFLOW_REQUEST_ID 
)
;

alter table FD.REL_BUILD_MONITOR add SNAPSHOT_INPUTS TEXT;

grant all privileges on FD.WORKFLOW_REQUEST_DATA to FD_ADMIN;

-- request snapshot inputs -- end

-- FLEXDEPLOY-9791 - Folder security adjustments - Start
UPDATE FD.FD_PERMISSION SET FOR_OBJECT_TYPE = 'PROJECT' WHERE ACTION_TYPE='CONFIGURECOMMANDS' AND OBJECT_TYPE = 'FOLDER';
UPDATE FD.FD_PERMISSION SET FOR_OBJECT_TYPE = 'PROJECT' WHERE ACTION_TYPE='CONFIGUREFILES' AND OBJECT_TYPE = 'FOLDER';
UPDATE FD.FD_PERMISSION SET FOR_OBJECT_TYPE = 'PROJECT' WHERE ACTION_TYPE='EXECUTE' AND OBJECT_TYPE = 'FOLDER';
UPDATE FD.FD_PERMISSION SET FOR_OBJECT_TYPE = 'PROJECT' WHERE ACTION_TYPE='INACTIVATEMISSINGFILES' AND OBJECT_TYPE = 'FOLDER';
UPDATE FD.FD_PERMISSION SET FOR_OBJECT_TYPE = 'PROJECT' WHERE ACTION_TYPE='VIEWLOGS' AND OBJECT_TYPE = 'FOLDER';
UPDATE FD.FD_PERMISSION SET FOR_OBJECT_TYPE = 'FOLDER' WHERE FOR_OBJECT_TYPE IS NULL AND OBJECT_TYPE = 'FOLDER';
UPDATE FD.FD_PERMISSION SET FOR_OBJECT_TYPE = NULL WHERE object_type <> 'FOLDER' and FOR_OBJECT_TYPE IS NOT NULL;

-- At Project we do not need CREATE and CREATERELEASE
DELETE FROM FD.FD_GROUP_PERMISSION WHERE PERMISSION_ID IN (SELECT p.PERMISSION_ID FROM FD.FD_PERMISSION p WHERE p.ACTION_TYPE='CREATE' AND p.OBJECT_TYPE = 'PROJECT');
DELETE FROM FD.FD_PERMISSION WHERE ACTION_TYPE='CREATE' AND OBJECT_TYPE = 'PROJECT';
DELETE FROM FD.FD_GROUP_PERMISSION WHERE PERMISSION_ID IN (SELECT p.PERMISSION_ID FROM FD.FD_PERMISSION p WHERE p.ACTION_TYPE='CREATERELEASE' AND p.OBJECT_TYPE = 'PROJECT');
DELETE FROM FD.FD_PERMISSION WHERE ACTION_TYPE='CREATERELEASE' AND OBJECT_TYPE = 'PROJECT';

-- FLEXDEPLOY-9791 - Folder security adjustments - End

ALTER TABLE FD.PURGE_PKG_VERSION_KEY ALTER COLUMN PACKAGE_OBJECT_EXECUTION_ID DROP NOT NULL;
ALTER TABLE FD.PURGE_PKG_VERSION_KEY ALTER COLUMN POE_EXECUTION_STATUS DROP NOT NULL;

ALTER TABLE FD.PURGE_PKG_VERSION_KEY ALTER COLUMN PLUGIN_EXECUTION_ID DROP NOT NULL;
ALTER TABLE FD.PURGE_PKG_VERSION_KEY ALTER COLUMN PLUGIN_EXECUTION_STATUS DROP NOT NULL;

-- START FLEXDEPLOY-12936

DROP VIEW IF EXISTS FD.vapplicationstatistics;
DROP VIEW IF EXISTS FD.VPROJECTTASKTIMELINE;
DROP VIEW IF EXISTS FD.VPROJECTTASKTIMELINEALL;
DROP VIEW IF EXISTS FD.MVPROJECTTASKTIMELINEALL;
DROP VIEW IF EXISTS FD.VCURRENTPROJECTTASK;
DROP VIEW IF EXISTS FD.VRPTENVPROJSTAT;


CREATE OR REPLACE VIEW FD.MVPROJECTTASKTIMELINEALL (ID, PROJECT_ID, WORKFLOW_TYPE, DURATION, DURATION_HOURS, DURATION_MINUTES, START_TIME, END_TIME, TASK_DATE, WORKFLOW_ID, STATUS, PROJECT_VERSION, ENVIRONMENT_CODE, INSTANCE_CODE, ENVIRONMENT_ID, INSTANCE_ID, FOLDER_NAME, PROJECT_NAME, WORKFLOW_NAME, FOLDER_ID, ENV_INST_ID, STREAM_NAME, PROJECT_WORKFLOW_ID, PROJECT_VERSION_ID, PROJECT_STREAM_ID) AS
  SELECT we.WorkFlow_execution_id id,
    we.project_id,
    pw.project_workflow_type workflow_type,
    trunc(EXTRACT(EPOCH FROM we.end_time - we.start_time)) duration, 
    trunc(EXTRACT(EPOCH FROM we.end_time - we.start_time)/3600) duration_hours,
    trunc(EXTRACT(EPOCH FROM we.end_time - we.start_time)/60) -
    trunc(EXTRACT(EPOCH FROM we.end_time - we.start_time)/3600)*60 duration_minutes ,
    we.start_time,
    we.end_time,
    CAST(we.start_time AS DATE) task_date,
    pw.workflow_id,
    SUBSTR(we.execution_status,1,1) status,
    pv.project_version_name project_version,
    env.environment_code,
    ins.instance_code,
    we.environment_id,
    we.instance_id,
    f.folder_name,
    p.project_name,
    w.workflow_name,
    p.folder_id,
    env_inst.env_inst_id,
    ps.stream_name,
    pw.project_workflow_id,
    pv.project_version_id,
    ps.project_stream_id
  FROM FD.Workflow_execution we
  LEFT OUTER JOIN FD.environment_Instance env_inst
  ON we.environment_id = env_inst.environment_id
  AND we.instance_id   = env_inst.instance_id,
    FD.project_workflow pw,
    FD.project_version pv
  LEFT OUTER JOIN FD.project_stream ps
  ON pv.project_stream_id = ps.project_stream_id,
    FD.environment env,
    FD.instance ins,
    FD.folder f,
    FD.project p,
    FD.workflow w
  WHERE we.project_workflow_id         = pw.project_workflow_id
  AND we.project_version_id            = pv.project_version_id
  AND we.environment_id                = env.environment_id
  AND we.instance_id                   = ins.instance_id
  AND we.project_id                    = p.project_id
  AND p.folder_id                      = f.folder_id
  AND pw.workflow_id                   = w.workflow_id
  AND we.end_time                     IS NOT NULL
  AND we.start_time                   IS NOT NULL
  AND we.parent_workflow_execution_id IS NULL
  AND w.workflow_type                 IN ('BUILD', 'DEPLOY', 'TEST', 'UTILITY', 'SYNCSTATE');
      
CREATE OR REPLACE VIEW FD.VPROJECTTASKTIMELINEALL
AS select ID,PROJECT_ID,WORKFLOW_TYPE,DURATION,DURATION_HOURS,DURATION_MINUTES,START_TIME,END_TIME,TASK_DATE,WORKFLOW_ID,STATUS,PROJECT_VERSION,ENVIRONMENT_CODE,INSTANCE_CODE,ENVIRONMENT_ID,INSTANCE_ID,FOLDER_NAME,PROJECT_NAME,WORKFLOW_NAME,FOLDER_ID,ENV_INST_ID,STREAM_NAME,PROJECT_WORKFLOW_ID,PROJECT_VERSION_ID,PROJECT_STREAM_ID from FD.MVProjectTaskTimeLineAll;

CREATE OR REPLACE VIEW FD.VPROJECTTASKTIMELINE
AS select ID,PROJECT_ID,WORKFLOW_TYPE,DURATION,DURATION_HOURS,DURATION_MINUTES,START_TIME,END_TIME,TASK_DATE,WORKFLOW_ID,STATUS,PROJECT_VERSION,ENVIRONMENT_CODE,INSTANCE_CODE,ENVIRONMENT_ID,INSTANCE_ID,FOLDER_NAME,PROJECT_NAME,WORKFLOW_NAME,FOLDER_ID,ENV_INST_ID,STREAM_NAME from FD.VProjectTaskTimeLineAll
where workflow_type in ('BUILD', 'DEPLOY', 'SYNCSTATE');

-- ignore nulls - still need to determine if this will hurt us.
CREATE OR REPLACE VIEW FD.VCURRENTPROJECTTASK
AS select
       we.workflow_execution_id,
       we.project_id,
       we.project_workflow_id,
       we.start_time,
       we.execution_status,
       we.project_version_id,
       we.environment_id,
       we.instance_id,
       we.last_exec_id,
       we.last_exec_start_time,
       we.last_exec_end_time,
       we.last_exec_status,
       we.last_exec_environment_id,
       we.last_exec_instance_id,
       p.project_name,
       pw.workflow_id,
       w.workflow_type,
       w.workflow_name,
       CAST(DATE_PART('hour', current_timestamp::timestamp - we.start_time::timestamp) AS int) Duration_hours,
       CAST(DATE_PART('minute', current_timestamp::timestamp - we.start_time::timestamp) AS int) Duration_minutes,
       env_inst.env_inst_id,
       env.ENVIRONMENT_NAME,
       ins.instance_name,
       env.ENVIRONMENT_CODE,
       ins.INSTANCE_CODE,
       CAST(DATE_PART('hour', we.last_exec_end_time::timestamp - we.last_exec_start_time::timestamp) AS int) last_hour_duration,
       CAST(DATE_PART('minute', we.last_exec_end_time::timestamp - we.last_exec_start_time::timestamp) AS int) last_minute_duration,
       CAST(EXTRACT(epoch FROM current_timestamp::timestamp - we.last_exec_end_time::timestamp)/3600 AS int) last_hour_ago,
       CAST(DATE_PART('minute', current_timestamp::timestamp - we.last_exec_end_time::timestamp) AS int) last_minute_ago,
       substr(we.last_exec_status,1,1) last_exec_state_id,
       last_env.ENVIRONMENT_NAME last_ENVIRONMENT_NAME,
       last_ins.instance_name last_instance_name,
       last_env.ENVIRONMENT_CODE last_ENVIRONMENT_CODE,
       last_ins.INSTANCE_CODE last_INSTANCE_CODE,
       pv.project_version_name project_version,
       f.folder_name,
       f.folder_id
from (
select workflow_execution_id,
       project_id,
       project_workflow_id,
       start_time,
       execution_status,
       project_version_id,
       environment_id,
       instance_id,
       FIRST_VALUE(workflow_execution_id) OVER (PARTITION BY project_id,  project_workflow_id order by case when execution_status='Running' then 0 else workflow_execution_id end desc) last_exec_id,
       FIRST_VALUE(start_time) OVER (PARTITION BY project_id,  project_workflow_id order by case when execution_status='Running' then 0 else workflow_execution_id end desc) last_exec_start_time,
       FIRST_VALUE(end_time) OVER (PARTITION BY project_id,  project_workflow_id order by case when execution_status='Running' then 0 else workflow_execution_id end desc) last_exec_end_time,
       FIRST_VALUE(execution_status) OVER (PARTITION BY project_id,  project_workflow_id order by case when execution_status='Running' then 0 else workflow_execution_id end desc) last_exec_status,
       FIRST_VALUE(environment_id) OVER (PARTITION BY project_id,  project_workflow_id order by case when execution_status='Running' then 0 else workflow_execution_id end desc) last_exec_environment_id,
       FIRST_VALUE(instance_id) OVER (PARTITION BY project_id,  project_workflow_id order by case when execution_status='Running' then 0 else workflow_execution_id end desc) last_exec_instance_id
from FD.WORKFLOW_EXECUTION
where parent_workflow_execution_id is null 
and (project_id,project_workflow_id) IN
    (SELECT DISTINCT project_id,
      project_workflow_id
    FROM FD.WORKFLOW_EXECUTION
    WHERE execution_status ='Running' 
	and parent_workflow_execution_id is null
    )
) we INNER JOIN FD.PROJECT p on we.project_id = p.PROJECT_ID
  INNER JOIN FD.PROJECT_WORKFLOW pw on we.project_workflow_id = pw.project_workflow_id 
  INNER JOIN FD.WORKFLOW w on pw.workflow_id = w.workflow_id
  INNER JOIN FD.ENVIRONMENT env on we.environment_id = env.environment_id
  INNER JOIN FD.INSTANCE ins on we.instance_id = ins.instance_id 
  INNER JOIN FD.ENVIRONMENT_INSTANCE env_inst on env_inst.instance_id = ins.instance_id and env_inst.environment_id = env.environment_id
  LEFT OUTER JOIN FD.ENVIRONMENT last_env on we.last_exec_environment_id = last_env.environment_id
  LEFT OUTER JOIN FD.INSTANCE last_ins on we.last_exec_instance_id = last_ins.instance_id
  INNER JOIN FD.PROJECT_VERSION pv on we.project_version_id = pv.project_version_id 
  INNER JOIN FD.FOLDER f on p.folder_id = f.folder_id 
where execution_status = 'Running'
       and w.workflow_type in ('BUILD', 'DEPLOY', 'TEST', 'UTILITY', 'PREDEPLOY', 'SYNCSTATE');

CREATE OR REPLACE VIEW FD.VRPTENVPROJSTAT as
SELECT we.workflow_execution_id,
  p.folder_id,
  p.project_id,
  p.project_name,
  pv.project_version_name,
  pv.scm_revision scm_revision,
  W.WORKFLOW_TYPE,
  W.WORKFLOW_ID,
  W.WORKFLOW_NAME,
  WV.WORKFLOW_VERSION,
  pv.all_files_requested,
  e.environment_id,
  e.environment_name,
  i.instance_id,
  i.instance_name,
  we.execution_status,
  pw.project_workflow_type,
  we.start_time,
  we.end_time,
  wr.created_by requested_by,
  wr.created_on requested_on,
  wr.flex_field_1,
  wr.flex_field_2,
  wr.flex_field_3,
  wr.flex_field_4,
  wr.flex_field_5,
  wr.flex_field_6,
  wr.flex_field_7,
  wr.flex_field_8,
  wr.flex_field_9,
  wr.flex_field_10,
  pv.flex_field_1 build_flex_field1,
  pv.flex_field_2 build_flex_field2,
  pv.flex_field_3 build_flex_field3,
  pv.flex_field_4 build_flex_field4,
  pv.flex_field_5 build_flex_field5,
  pv.flex_field_6 build_flex_field6,
  pv.flex_field_7 build_flex_field7,
  pv.flex_field_8 build_flex_field8,
  pv.flex_field_9 build_flex_field9,
  pv.flex_field_10 build_flex_field10,
  NULL package_name,
  NULL package_created_by,
  NULL package_created_on,
  NULL package_updated_by,
  NULL package_updated_on,
  '' object_path,
  '' object_type,
  '' sub_component_name,
  '' sub_component_type,
  p.partial_deployments,
  f.folder_name,
  wr.rel_definition_id,
  wr.rel_snapshot_id,
  rd.rel_name,
  rd.rel_status,
  pd.name pipeline_name,
  rs.rel_snapshot,
  rs.created_by snapshot_submitted_by,
  wr.workflow_request_id,
  wr.pipeline_stage_exec_id,
  (
   SELECT STRING_AGG(WI.WORK_ITEM_NUMBER,', '
        ORDER BY WI.WORK_ITEM_NUMBER)
      FROM FD.WORKFLOW_EXECUTION_WORK_ITEM EXE_WI,
        FD.WORK_ITEM WI
      WHERE EXE_WI.WORKFLOW_EXECUTION_ID = WE.WORKFLOW_EXECUTION_ID
          AND WI.WORK_ITEM_ID                = EXE_WI.WORK_ITEM_ID
       ) AS WORK_ITEM_IDS,
  (SELECT STRING_AGG(TICKET.TICKET_NUMBER,', '
          ORDER BY TICKET.TICKET_NUMBER)
        FROM FD.WORKFLOW_REQUEST_TICKET WRT,
             FD.CMS_TICKET TICKET
        WHERE WRT.CMS_TICKET_ID    =TICKET.CMS_TICKET_ID
          AND WRT.WORKFLOW_REQUEST_ID=WR.WORKFLOW_REQUEST_ID
       ) external_ticket,
  pv.project_version_id,
  (
  SELECT STRING_AGG(HT.ACTION_BY,', '
        ORDER BY HT.ACTION_BY)
        FROM FD.HUMAN_TASK HT
        WHERE (HT.WORKFLOW_REQUEST_ID  =WR.WORKFLOW_REQUEST_ID
          OR (HT.PIPELINE_STAGE_EXEC_ID  =WR.PIPELINE_STAGE_EXEC_ID
           AND HT.PIPELINE_STAGE_GATE_ID IS NOT NULL)
          OR HT.WORKFLOW_EXECUTION_ID    = WE.PREDEPLOY_WORKFLOW_EXEC_ID)
          AND HT.TASK_STATUS             ='APPROVED'
          AND HT.TASK_TYPE              IN ('PRE_DEPLOY_REVIEW', 'APPROVAL')
  ) APPROVED_BY_USERNAMES,
  ps.stream_name,
  wr.force_deploy as force,
  wr.folder_request_id,
  NULL PKG_STATUS,
  NULL COMMIT_USER
FROM fd.workflow_execution we,
  fd.project p,
  fd.project_version pv
  left outer join fd.project_stream ps on pv.project_stream_id = ps.project_stream_id,
  fd.environment e,
  fd.project_workflow pw,
  fd.instance i,
  fd.project_wf_current_status pwcs,
  fd.workflow_request wr
  LEFT OUTER JOIN fd.rel_definition rd ON wr.rel_definition_id = rd.rel_definition_id
  LEFT OUTER JOIN fd.pipeline_definition pd ON rd.pipeline_definition_id = pd.pipeline_definition_id
  LEFT OUTER JOIN fd.rel_snapshot rs ON wr.rel_snapshot_id = rs.rel_snapshot_id,
  fd.folder f,
  FD.WORKFLOW_VERSION wv,
  FD.WORKFLOW W
WHERE p.project_id = we.project_id
  AND p.folder_id = f.folder_id
  AND pv.project_version_id = we.project_version_id
  AND e.environment_id = we.environment_id
  AND i.instance_id = we.instance_id
  AND pw.project_workflow_id = we.project_workflow_id
  AND p.partial_deployments = 'N'
  AND pw.project_workflow_type in ('DEPLOY', 'SYNCSTATE')
  AND wr.workflow_request_id = we.workflow_request_id
  AND we.workflow_execution_id = pwcs.workflow_execution_id
  and WV.WORKFLOW_VERSION_ID = WE.WORKFLOW_VERSION_ID
  and W.WORKFLOW_ID = WE.WORKFLOW_ID
UNION ALL
SELECT we.workflow_execution_id,
  p.folder_id,
  p.project_id,
  p.project_name,
  pv.project_version_name,
  pkgobj.scm_revision scm_revision,
  W.WORKFLOW_TYPE,
  W.WORKFLOW_ID,
  W.WORKFLOW_NAME,
  WV.WORKFLOW_VERSION,
  pv.all_files_requested,
  e.environment_id,
  e.environment_name,
  i.instance_id,
  i.instance_name,
  we.execution_status,
  pw.project_workflow_type,
  we.start_time,
  we.end_time,
  wr.created_by requested_by,
  wr.created_on requested_on,
  wr.flex_field_1,
  wr.flex_field_2,
  wr.flex_field_3,
  wr.flex_field_4,
  wr.flex_field_5,
  wr.flex_field_6,
  wr.flex_field_7,
  wr.flex_field_8,
  wr.flex_field_9,
  wr.flex_field_10,
  pv.flex_field_1 build_flex_field1,
  pv.flex_field_2 build_flex_field2,
  pv.flex_field_3 build_flex_field3,
  pv.flex_field_4 build_flex_field4,
  pv.flex_field_5 build_flex_field5,
  pv.flex_field_6 build_flex_field6,
  pv.flex_field_7 build_flex_field7,
  pv.flex_field_8 build_flex_field8,
  pv.flex_field_9 build_flex_field9,
  pv.flex_field_10 build_flex_field10,
  pv.package_name as package_name,
  PP.CREATED_BY AS PACKAGE_CREATED_BY,
  PP.CREATED_ON AS PACKAGE_CREATED_ON,
  PP.UPDATED_BY AS PACKAGE_UPDATED_BY,
  PP.UPDATED_ON AS PACKAGE_UPDATED_ON,  
  prjobj.object_path object_path,
  objtyp.object_type_code object_type,
  prjobj.sub_component_name,
  prjobj.sub_component_type,
  p.partial_deployments,
  f.folder_name,
  wr.rel_definition_id,
  wr.rel_snapshot_id,
  rd.rel_name,
  rd.rel_status,
  pd.name pipeline_name,
  rs.rel_snapshot,
  rs.created_by snapshot_submitted_by,
  wr.workflow_request_id,
  wr.pipeline_stage_exec_id,
  (SELECT STRING_AGG(WI.WORK_ITEM_NUMBER,', '
        ORDER BY WI.WORK_ITEM_NUMBER)
      FROM FD.WORKFLOW_EXECUTION_WORK_ITEM EXE_WI,
        FD.WORK_ITEM WI
      WHERE EXE_WI.WORKFLOW_EXECUTION_ID = WE.WORKFLOW_EXECUTION_ID
          AND WI.WORK_ITEM_ID                = EXE_WI.WORK_ITEM_ID
       ) AS WORK_ITEM_IDS,
  (SELECT STRING_AGG(TICKET.TICKET_NUMBER,', '
          ORDER BY TICKET.TICKET_NUMBER)
        FROM FD.WORKFLOW_REQUEST_TICKET WRT,
             FD.CMS_TICKET TICKET
        WHERE WRT.CMS_TICKET_ID    =TICKET.CMS_TICKET_ID
          AND WRT.WORKFLOW_REQUEST_ID=WR.WORKFLOW_REQUEST_ID
       ) external_ticket,
  pv.project_version_id,
    (SELECT STRING_AGG(HT.ACTION_BY,', '
          ORDER BY HT.ACTION_BY)
        FROM FD.HUMAN_TASK HT
        WHERE (HT.WORKFLOW_REQUEST_ID  =WR.WORKFLOW_REQUEST_ID
          OR (HT.PIPELINE_STAGE_EXEC_ID  =WR.PIPELINE_STAGE_EXEC_ID
            AND HT.PIPELINE_STAGE_GATE_ID IS NOT NULL)
          OR HT.WORKFLOW_EXECUTION_ID    = WE.PREDEPLOY_WORKFLOW_EXEC_ID)
          AND HT.TASK_STATUS             ='APPROVED'
          AND HT.TASK_TYPE              IN ('PRE_DEPLOY_REVIEW', 'APPROVAL')
       ) APPROVED_BY_USERNAMES,
  ps.stream_name,
   wr.force_deploy as force,
  wr.folder_request_id,
  (SELECT STRING_AGG(PKGEXEC.EXECUTION_STATUS,','
    ORDER BY PKGEXEC.EXECUTION_STATUS)
   FROM FD.PLUGIN_EXECUTION PEXEC,
        FD.PACKAGE_OBJECT_EXECUTION PKGEXEC
      WHERE PKGOBJ.PACKAGE_OBJECT_ID IS NOT NULL
        AND PKGEXEC.PACKAGE_OBJECT_ID   = PKGOBJ.PACKAGE_OBJECT_ID
        AND PKGEXEC.PLUGIN_EXECUTION_ID = PEXEC.PLUGIN_EXECUTION_ID
        AND PEXEC.WORKFLOW_EXECUTION_ID = WE.WORKFLOW_EXECUTION_ID
        AND W.WORKFLOW_TYPE             in ('DEPLOY', 'SYNCSTATE')
      ) PKG_STATUS,
      POR.COMMIT_USER
FROM fd.workflow_execution we,
  fd.project p,
  fd.project_version pv
  LEFT OUTER JOIN fd.project_package pp ON pv.project_id = pp.project_id
  AND pv.package_name = pp.package_name
  left outer join fd.project_stream ps on ps.project_stream_id = pv.project_stream_id,
  fd.environment e,
  fd.project_workflow pw,
  fd.instance i,
  fd.package_obj_current_status pkjobjcs,
  fd.workflow_request wr
  LEFT OUTER JOIN fd.rel_definition rd ON wr.rel_definition_id = rd.rel_definition_id
  LEFT OUTER JOIN fd.pipeline_definition pd ON rd.pipeline_definition_id = pd.pipeline_definition_id
  LEFT OUTER JOIN fd.rel_snapshot rs ON wr.rel_snapshot_id = rs.rel_snapshot_id,
  fd.package_object pkgobj
  LEFT OUTER JOIN fd.project_object_revision por ON por.project_object_id=pkgobj.project_object_id
  AND por.scm_revision = pkgobj.scm_revision,
  fd.project_object prjobj,
  fd.object_type objtyp,
  fd.folder f,
  FD.WORKFLOW_VERSION WV,
  FD.WORKFLOW W
WHERE p.project_id = we.project_id
  AND p.folder_id = f.folder_id
  AND pv.project_version_id = we.project_version_id
  AND e.environment_id = we.environment_id
  AND i.instance_id = we.instance_id
  AND pw.project_workflow_id = we.project_workflow_id
  AND p.partial_deployments = 'Y'
  AND pw.project_workflow_type in ( 'DEPLOY', 'SYNCSTATE')
  AND wr.workflow_request_id = we.workflow_request_id
  AND we.workflow_execution_id = pkjobjcs.workflow_execution_id
  AND p.project_id = pv.project_id
  AND pkgobj.project_object_id = pkjobjcs.project_object_id
  AND pv.project_version_id = pkgobj.project_version_id
  AND pkgobj.project_object_id = prjobj.project_object_id
  AND prjobj.object_type_id = objtyp.object_type_id
  and WV.WORKFLOW_VERSION_ID = WE.WORKFLOW_VERSION_ID
  and W.WORKFLOW_ID = WE.WORKFLOW_ID;


GRANT ALL PRIVILEGES ON FD.VPROJECTTASKTIMELINE TO FD_ADMIN;
GRANT ALL PRIVILEGES ON FD.VPROJECTTASKTIMELINEALL TO FD_ADMIN;
GRANT ALL PRIVILEGES ON FD.MVPROJECTTASKTIMELINEALL TO FD_ADMIN;
GRANT ALL PRIVILEGES ON FD.VCURRENTPROJECTTASK TO FD_ADMIN;
GRANT ALL PRIVILEGES ON FD.VRPTENVPROJSTAT TO FD_ADMIN;

-- END FLEXDEPLOY-12936

-- FLEXDEPLOY-13094

CREATE OR REPLACE VIEW fd.VOBJECTPERMISSION AS
    SELECT
        ug.user_id,
        p.object_id,
        p.object_type,
        p.action_type
    FROM
        fd.fd_user_group ug
        INNER JOIN fd.fd_group_permission gp ON ug.group_id = gp.group_id
        INNER JOIN fd.fd_permission       p ON gp.permission_id = p.permission_id
        where (p.for_object_type is null or p.for_object_type='FOLDER')
    UNION
    SELECT
        ug.user_id,
        p.object_id,
        p.object_type,
        p.action_type
    FROM
        fd.fd_user_ext_group ug
        INNER JOIN fd.fd_group_permission gp ON ug.group_id = gp.group_id
        INNER JOIN fd.fd_permission       p ON gp.permission_id = p.permission_id
        where (p.for_object_type is null or p.for_object_type='FOLDER');


-- END FLEXDEPLOY-13094

-- begin 9.0 speed indexes for project screens / dashboard. (postgres only)
CREATE INDEX wfr_pid_con on fd.workflow_request (project_id,created_on);
CREATE INDEX wfe_pid_wfr_id_w_pwfeid_nonnull ON fd.workflow_execution (project_id, WORKFLOW_REQUEST_ID,START_TIME) where PARENT_WORKFLOW_EXECUTION_ID is null;
CREATE INDEX wfe_pid_w_deploy_pwfeid_nonnull on fd.WORKFLOW_EXECUTION (PROJECT_ID) where WORKFLOW_TYPE ='DEPLOY' and PARENT_WORKFLOW_EXECUTION_ID is null;
CREATE INDEX wfe_eid_pvie_w_es_success_wt_deploy on fd.WORKFLOW_EXECUTION (environment_id, PROJECT_VERSION_ID,END_TIME) where EXECUTION_STATUS = 'Success' and WORKFLOW_TYPE  in ('DEPLOY', 'SYNCSTATE');

-- end 9.0 speed indexes for project screens / dashboard. (postgres only)



--leave at the end
commit;