-- 6.5.0.4
insert into FD.FD_FLEXDEPLOY_VERSION values('6.5.0.4',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

update fd.post_refresh_request set request_status='SUBMITTED' where request_status='DEPLOYING';
update fd.post_refresh_request set request_status='COMPLETED' where request_status='COMPLETE';

commit;
