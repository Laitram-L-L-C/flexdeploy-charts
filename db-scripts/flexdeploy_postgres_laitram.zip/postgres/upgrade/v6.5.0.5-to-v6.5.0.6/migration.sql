set define off;
set echo on;

-- 6.5.0.5
insert into FD.FD_FLEXDEPLOY_VERSION values('6.5.0.6',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

CREATE INDEX FDIX711 ON FD.EVENT_MESSAGE (STATUS);
CREATE INDEX FDIX712 ON FD.HUMAN_TASK (TASK_STATUS);
CREATE INDEX FDIX713 ON FD.HUMAN_TASK (EXTERNAL_SYSTEM_TYPE);
CREATE INDEX FDIX714 ON FD.SCHEDULED_TASK (PIPELINE_STAGE_GATE_EXEC_ID);
CREATE INDEX FDIX715 ON FD.WORKFLOW_EXECUTION (PROJECT_WORKFLOW_ID);
CREATE INDEX FDIX716 ON FD.PROJECT_TRIGGER (TRIGGER_TYPE);
CREATE INDEX FDIX717 ON FD.PROJECT_WORKFLOW (PROJECT_WORKFLOW_TYPE);

update ff.db_properties_data set db_properties_value = '120' where db_properties_id in 
(select db_properties_id from ff.db_properties where db_properties_key = 'FD_SESSION_INACTIVITY_TIMEOUT' and CASE WHEN db_properties_value~E'^\\d+$' THEN db_properties_value::integer ELSE 0 END > 120)
;

commit;
