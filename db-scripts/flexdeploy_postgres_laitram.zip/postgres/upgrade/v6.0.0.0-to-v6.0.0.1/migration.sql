-- 6.0.0.1
insert into FD.FD_FLEXDEPLOY_VERSION values('6.0.0.1',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

grant all privileges on FD.PROJECT_STREAM_CONTAINER to FD_ADMIN;
grant all privileges on FD.PROJECT_K8S_CONFIG to FD_ADMIN;
grant all privileges on FD.PROJECT_HELM_VALUE to FD_ADMIN;
grant all privileges on FD.PROJECT_CONTAINER_CONFIG to FD_ADMIN;