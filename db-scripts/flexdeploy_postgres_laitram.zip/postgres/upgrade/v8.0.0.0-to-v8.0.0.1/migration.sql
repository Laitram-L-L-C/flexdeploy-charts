insert into FD.FD_FLEXDEPLOY_VERSION values('8.0.0.1',null,current_date,'SYSTEM',current_date,'SYSTEM',1);

-- FLEXDEPLOY-11886
UPDATE FD.flex_field_metadata SET SUB_DATATYPE = 'TextField' WHERE SUB_DATATYPE is NULL and DATATYPE = 'String';
UPDATE FD.flex_field_metadata SET SUB_DATATYPE = 'Long' WHERE SUB_DATATYPE is NULL and DATATYPE = 'Integer';
UPDATE FD.flex_field_metadata SET SUB_DATATYPE = 'Double' WHERE SUB_DATATYPE is NULL and DATATYPE = 'Double';
UPDATE FD.flex_field_metadata SET SUB_DATATYPE = 'Long' WHERE SUB_DATATYPE is NULL and DATATYPE = 'Long';
UPDATE FD.flex_field_metadata SET SUB_DATATYPE = 'Boolean' WHERE SUB_DATATYPE is NULL and DATATYPE = 'Boolean';
UPDATE FD.flex_field_metadata SET SUB_DATATYPE = 'Directory' WHERE SUB_DATATYPE = 'DIRECTORY';
UPDATE FD.flex_field_metadata SET DATATYPE = 'Long' WHERE DATATYPE = 'Integer';

--FLEXDEPLOY-10848
delete from fd.project_trigger where rel_definition_id is not null and rel_definition_id not in (select rel_definition_id from fd.rel_definition);
delete from fd.project_trigger where environment_id is not null and environment_id not in (select environment_id from fd.environment);
delete from fd.project_trigger where INSTANCE_id is not null and INSTANCE_id not in (select INSTANCE_id from fd.INSTANCE);

--FLEXDEPLOY-10848
ALTER TABLE FD.PROJECT_TRIGGER
ADD CONSTRAINT PROJECT_TRIGGER_ENV_FK FOREIGN KEY
(
  ENVIRONMENT_ID 
)
REFERENCES FD.ENVIRONMENT
(
  ENVIRONMENT_ID 
)
;

ALTER TABLE FD.PROJECT_TRIGGER
ADD CONSTRAINT PROJECT_TRIGGER_INSTANCE_FK FOREIGN KEY
(
  INSTANCE_ID 
)
REFERENCES FD.INSTANCE
(
  INSTANCE_ID 
)
;

ALTER TABLE FD.PROJECT_TRIGGER
ADD CONSTRAINT PROJECT_TRIGGER_REL_DEF_FK FOREIGN KEY
(
  REL_DEFINITION_ID 
)
REFERENCES FD.REL_DEFINITION
(
  REL_DEFINITION_ID 
)
;

-- FLEXDEPLOY-11911 - missed in previous migration.sql
update fd.instance set sub_group_code='Boomi' where group_code = 'CLOUD' and sub_group_code='DellBoomi';
commit;
-- FLEXDEPLOY-11911

-- Reexecuting this as we had a bug in AutoUpload process - start
UPDATE fd.property_key_definition
SET
    property_key_sub_datatype = 'TextField'
WHERE
    property_key_sub_datatype IS NULL
    AND property_key_datatype = 'String';

UPDATE fd.property_key_definition
SET
    property_key_sub_datatype = 'Long'
WHERE
    property_key_sub_datatype IS NULL
    AND property_key_datatype = 'Integer';

UPDATE fd.property_key_definition
SET
    property_key_sub_datatype = 'Boolean'
WHERE
    property_key_sub_datatype IS NULL
    AND property_key_datatype = 'Boolean';

UPDATE fd.property_key_definition
SET
    property_key_sub_datatype = 'Double'
WHERE
    property_key_sub_datatype IS NULL
    AND property_key_datatype = 'Double';

UPDATE fd.property_key_definition
SET
    property_key_sub_datatype = 'Directory'
WHERE
    property_key_sub_datatype = 'DIRECTORY';

commit;
-- Reexecuting this as we had a bug in AutoUpload process - end

-- leave at the end
commit;