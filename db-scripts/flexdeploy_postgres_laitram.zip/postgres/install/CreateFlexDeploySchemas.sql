\i  scripts/CreateSchemas.sql;
\i  scripts/FFPostgres.sql;
\i  scripts/FDPostgresObjects.sql;
\i  scripts/FDPostgresGenerateProcedures.sql;
\i  scripts/Grants.sql;
\q