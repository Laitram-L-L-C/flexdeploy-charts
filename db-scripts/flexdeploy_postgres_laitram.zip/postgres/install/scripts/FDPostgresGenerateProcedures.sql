CREATE OR REPLACE VIEW FD.VTESTAUTOMATIONRESULT
AS select test_run.project_id,
       test_run.environment_id,
       test_run.instance_id,
       test_run.project_stream_id,
       test_run.test_type_id,
       CAST(test_run.start_time AS DATE) as test_date,
       ts.Test_set_id,
       ts.test_set_name,
       td.test_definition_id,
       td.test_definition_name,
       tr.test_case_name,
       tr.status,
       tr.duration,
       tr.MinRespTime,
       tr.MaxRespTime,
       tr.AvgRespTime,
       e.environment_name,
       e.environment_code,
       tdr.start_time,
       f.folder_name
from FD.TEST_RESULT tr, FD.TEST_DEFINITION_RUN tdr, FD.TEST_DEFINITION td, FD.TEST_SET_RUN tsr, FD.TEST_SET ts, FD.TEST_RUN test_run, FD.ENVIRONMENT e, FD.PROJECT p, FD.FOLDER f
where tr.test_definition_run_id = tdr.test_definition_run_id and
      tdr.Test_definition_id = td.Test_definition_id and
      tdr.test_set_run_id = tsr.test_set_run_id and
      tsr.test_set_id = ts.test_set_id and
      tsr.Test_run_id = test_run.Test_run_id and
      test_run.environment_id = e.environment_id and
      test_run.project_id = p.project_id and
      p.folder_id = f.folder_id;

CREATE OR REPLACE VIEW FD.VRELEASESNAPSHOTENVIRONMENT
AS SELECT execution.rel_definition_id,
  execution.ENVIRONMENT_ID,
  execution.rel_snapshot_id,
  execution.UPDATED_BY,
  execution.UPDATED_ON,
  execution.on_deck_snapshot_id,
  env.environment_code,
  env.environment_name,
  rs.Rel_snapshot,
  on_deck_rs.Rel_snapshot on_desck_rel_snapshot,
  exec_id,
  execution.start_time,
  execution.end_time,
  ps.sequence_number
FROM
  (SELECT deploy_exec.rel_definition_id,
    stage_exec.ENVIRONMENT_ID,
    stage_exec.rel_snapshot_id,
    stage_exec.UPDATED_BY,
    stage_exec.UPDATED_ON,
    deploy_exec.exec_id,
    stage_exec.start_time,
    stage_exec.end_time,
    stage_exec.pipeline_definition_id,
    (SELECT rel_snapshot_id
    FROM fd.pipeline_stage_exec
    WHERE pipeline_stage_exec_id =
      (SELECT MAX(pipeline_stage_exec_id)
      FROM fd.pipeline_stage_exec min_exec,
        fd.rel_snapshot min_snap
      WHERE min_exec.rel_snapshot_id      = min_snap.rel_snapshot_id
      AND min_exec.pipeline_stage_exec_id > deploy_exec.exec_id
      AND min_snap.rel_definition_id      = deploy_exec.rel_definition_id
      AND min_exec.ENVIRONMENT_ID         = deploy_exec.ENVIRONMENT_ID
      AND min_exec.execution_status in ('RUNNING_GATES','GATES_COMPLETE','RUNNING_STEPS')
      )
    ) on_deck_snapshot_id
  FROM fd.pipeline_stage_exec stage_exec,
    (SELECT snap.rel_definition_id,
      exec.ENVIRONMENT_ID,
      MAX(exec.pipeline_stage_exec_id) exec_id
    FROM fd.pipeline_stage_exec EXEC,
      fd.rel_snapshot snap
    WHERE exec.rel_snapshot_id = snap.rel_snapshot_id
    AND exec.execution_status  = 'SUCCESSFUL'
    GROUP BY snap.rel_definition_id,
      exec.ENVIRONMENT_ID
    ) deploy_exec
  WHERE stage_exec.pipeline_stage_exec_id = deploy_exec.exec_id
  ) execution
  left outer join fd.Rel_snapshot on_deck_rs on execution.on_deck_snapshot_id = on_deck_rs.rel_snapshot_id,
  fd.Environment env,
  fd.Rel_snapshot rs,
  fd.pipeline_definition pd,
  fd.pipeline_stage ps
WHERE execution.ENVIRONMENT_ID    = env.ENVIRONMENT_ID
AND execution.rel_snapshot_id     = rs.rel_snapshot_id
AND pd.pipeline_definition_id = execution.pipeline_definition_id
AND pd.active_pipeline_version_id = ps.pipeline_version_id
and ps.environment_id = execution.ENVIRONMENT_ID;

CREATE OR REPLACE VIEW FD.MVPROJECTTASKTIMELINEALL (ID, PROJECT_ID, WORKFLOW_TYPE, DURATION, DURATION_HOURS, DURATION_MINUTES, START_TIME, END_TIME, TASK_DATE, WORKFLOW_ID, STATUS, PROJECT_VERSION, ENVIRONMENT_CODE, INSTANCE_CODE, ENVIRONMENT_ID, INSTANCE_ID, FOLDER_NAME, PROJECT_NAME, WORKFLOW_NAME, FOLDER_ID, ENV_INST_ID, STREAM_NAME, PROJECT_WORKFLOW_ID, PROJECT_VERSION_ID, PROJECT_STREAM_ID) AS
  SELECT we.WorkFlow_execution_id id,
    we.project_id,
    pw.project_workflow_type workflow_type,
    trunc(EXTRACT(EPOCH FROM we.end_time - we.start_time)) duration, 
    trunc(EXTRACT(EPOCH FROM we.end_time - we.start_time)/3600) duration_hours,
    trunc(EXTRACT(EPOCH FROM we.end_time - we.start_time)/60) -
    trunc(EXTRACT(EPOCH FROM we.end_time - we.start_time)/3600)*60 duration_minutes ,
    we.start_time,
    we.end_time,
    CAST(we.start_time AS DATE) task_date,
    pw.workflow_id,
    SUBSTR(we.execution_status,1,1) status,
    pv.project_version_name project_version,
    env.environment_code,
    ins.instance_code,
    we.environment_id,
    we.instance_id,
    f.folder_name,
    p.project_name,
    w.workflow_name,
    p.folder_id,
    env_inst.env_inst_id,
    ps.stream_name,
    pw.project_workflow_id,
    pv.project_version_id,
    ps.project_stream_id
  FROM FD.Workflow_execution we
  LEFT OUTER JOIN FD.environment_Instance env_inst
  ON we.environment_id = env_inst.environment_id
  AND we.instance_id   = env_inst.instance_id,
    FD.project_workflow pw,
    FD.project_version pv
  LEFT OUTER JOIN FD.project_stream ps
  ON pv.project_stream_id = ps.project_stream_id,
    FD.environment env,
    FD.instance ins,
    FD.folder f,
    FD.project p,
    FD.workflow w
  WHERE we.project_workflow_id         = pw.project_workflow_id
  AND we.project_version_id            = pv.project_version_id
  AND we.environment_id                = env.environment_id
  AND we.instance_id                   = ins.instance_id
  AND we.project_id                    = p.project_id
  AND p.folder_id                      = f.folder_id
  AND pw.workflow_id                   = w.workflow_id
  AND we.end_time                     IS NOT NULL
  AND we.start_time                   IS NOT NULL
  AND we.parent_workflow_execution_id IS NULL
  AND w.workflow_type                 IN ('BUILD', 'DEPLOY', 'TEST', 'UTILITY', 'SYNCSTATE');
      

CREATE OR REPLACE VIEW FD.VPROJECTTASKTIMELINEALL
AS select ID,PROJECT_ID,WORKFLOW_TYPE,DURATION,DURATION_HOURS,DURATION_MINUTES,START_TIME,END_TIME,TASK_DATE,WORKFLOW_ID,STATUS,PROJECT_VERSION,ENVIRONMENT_CODE,INSTANCE_CODE,ENVIRONMENT_ID,INSTANCE_ID,FOLDER_NAME,PROJECT_NAME,WORKFLOW_NAME,FOLDER_ID,ENV_INST_ID,STREAM_NAME,PROJECT_WORKFLOW_ID,PROJECT_VERSION_ID,PROJECT_STREAM_ID from FD.MVProjectTaskTimeLineAll;

CREATE OR REPLACE VIEW FD.VPROJECTTASKTIMELINE
AS select ID,PROJECT_ID,WORKFLOW_TYPE,DURATION,DURATION_HOURS,DURATION_MINUTES,START_TIME,END_TIME,TASK_DATE,WORKFLOW_ID,STATUS,PROJECT_VERSION,ENVIRONMENT_CODE,INSTANCE_CODE,ENVIRONMENT_ID,INSTANCE_ID,FOLDER_NAME,PROJECT_NAME,WORKFLOW_NAME,FOLDER_ID,ENV_INST_ID,STREAM_NAME from FD.VProjectTaskTimeLineAll
where workflow_type in ('BUILD', 'DEPLOY', 'SYNCSTATE');

-- ignore nulls - still need to determine if this will hurt us.
CREATE OR REPLACE VIEW FD.VCURRENTPROJECTTASK
AS select
       we.workflow_execution_id,
       we.project_id,
       we.project_workflow_id,
       we.start_time,
       we.execution_status,
       we.project_version_id,
       we.environment_id,
       we.instance_id,
       we.last_exec_id,
       we.last_exec_start_time,
       we.last_exec_end_time,
       we.last_exec_status,
       we.last_exec_environment_id,
       we.last_exec_instance_id,
       p.project_name,
       pw.workflow_id,
       w.workflow_type,
       w.workflow_name,
       CAST(DATE_PART('hour', current_timestamp::timestamp - we.start_time::timestamp) AS int) Duration_hours,
       CAST(DATE_PART('minute', current_timestamp::timestamp - we.start_time::timestamp) AS int) Duration_minutes,
       env_inst.env_inst_id,
       env.ENVIRONMENT_NAME,
       ins.instance_name,
       env.ENVIRONMENT_CODE,
       ins.INSTANCE_CODE,
       CAST(DATE_PART('hour', we.last_exec_end_time::timestamp - we.last_exec_start_time::timestamp) AS int) last_hour_duration,
       CAST(DATE_PART('minute', we.last_exec_end_time::timestamp - we.last_exec_start_time::timestamp) AS int) last_minute_duration,
       CAST(EXTRACT(epoch FROM current_timestamp::timestamp - we.last_exec_end_time::timestamp)/3600 AS int) last_hour_ago,
       CAST(DATE_PART('minute', current_timestamp::timestamp - we.last_exec_end_time::timestamp) AS int) last_minute_ago,
       substr(we.last_exec_status,1,1) last_exec_state_id,
       last_env.ENVIRONMENT_NAME last_ENVIRONMENT_NAME,
       last_ins.instance_name last_instance_name,
       last_env.ENVIRONMENT_CODE last_ENVIRONMENT_CODE,
       last_ins.INSTANCE_CODE last_INSTANCE_CODE,
       pv.project_version_name project_version,
       f.folder_name,
       f.folder_id
from (
select workflow_execution_id,
       project_id,
       project_workflow_id,
       start_time,
       execution_status,
       project_version_id,
       environment_id,
       instance_id,
       FIRST_VALUE(workflow_execution_id) OVER (PARTITION BY project_id,  project_workflow_id order by case when execution_status='Running' then 0 else workflow_execution_id end desc) last_exec_id,
       FIRST_VALUE(start_time) OVER (PARTITION BY project_id,  project_workflow_id order by case when execution_status='Running' then 0 else workflow_execution_id end desc) last_exec_start_time,
       FIRST_VALUE(end_time) OVER (PARTITION BY project_id,  project_workflow_id order by case when execution_status='Running' then 0 else workflow_execution_id end desc) last_exec_end_time,
       FIRST_VALUE(execution_status) OVER (PARTITION BY project_id,  project_workflow_id order by case when execution_status='Running' then 0 else workflow_execution_id end desc) last_exec_status,
       FIRST_VALUE(environment_id) OVER (PARTITION BY project_id,  project_workflow_id order by case when execution_status='Running' then 0 else workflow_execution_id end desc) last_exec_environment_id,
       FIRST_VALUE(instance_id) OVER (PARTITION BY project_id,  project_workflow_id order by case when execution_status='Running' then 0 else workflow_execution_id end desc) last_exec_instance_id
from FD.WORKFLOW_EXECUTION
where parent_workflow_execution_id is null 
and (project_id,project_workflow_id) IN
    (SELECT DISTINCT project_id,
      project_workflow_id
    FROM FD.WORKFLOW_EXECUTION
    WHERE execution_status ='Running' 
	and parent_workflow_execution_id is null
    )
) we INNER JOIN FD.PROJECT p on we.project_id = p.PROJECT_ID
  INNER JOIN FD.PROJECT_WORKFLOW pw on we.project_workflow_id = pw.project_workflow_id 
  INNER JOIN FD.WORKFLOW w on pw.workflow_id = w.workflow_id
  INNER JOIN FD.ENVIRONMENT env on we.environment_id = env.environment_id
  INNER JOIN FD.INSTANCE ins on we.instance_id = ins.instance_id 
  INNER JOIN FD.ENVIRONMENT_INSTANCE env_inst on env_inst.instance_id = ins.instance_id and env_inst.environment_id = env.environment_id
  LEFT OUTER JOIN FD.ENVIRONMENT last_env on we.last_exec_environment_id = last_env.environment_id
  LEFT OUTER JOIN FD.INSTANCE last_ins on we.last_exec_instance_id = last_ins.instance_id
  INNER JOIN FD.PROJECT_VERSION pv on we.project_version_id = pv.project_version_id 
  INNER JOIN FD.FOLDER f on p.folder_id = f.folder_id 
where execution_status = 'Running'
       and w.workflow_type in ('BUILD', 'DEPLOY', 'TEST', 'UTILITY', 'PREDEPLOY', 'SYNCSTATE');

CREATE OR REPLACE VIEW FD.VPARENTFLDR (FOLDER_ID) AS 
WITH RECURSIVE FOLDER  as (
    select f.FOLDER_ID
     from FD.FOLDER f
     UNION ALL
     SELECT f2.FOLDER_ID
     FROM FD.FOLDER f2
    INNER JOIN FOLDER efolder 
      ON efolder.FOLDER_ID = f2.PARENT_FOLDER_ID
)
SELECT * FROM FOLDER;

CREATE or replace VIEW FD.VPARENTWKFLW as
WITH RECURSIVE WKFLW  as (
    select we.WORKFLOW_EXECUTION_ID 
     from FD.WORKFLOW_EXECUTION we
     UNION ALL
     SELECT e.WORKFLOW_EXECUTION_ID
     FROM FD.WORKFLOW_EXECUTION e
    INNER JOIN WKFLW ewkflw 
      ON ewkflw.WORKFLOW_EXECUTION_ID = e.PARENT_WORKFLOW_EXECUTION_ID
	  and e.PARENT_WORKFLOW_EXECUTION_ID is not null
)
SELECT * FROM WKFLW;
  
  CREATE OR REPLACE VIEW FD.VACTVPROJWFULLPATH (PROJECT_ID, FOLDER_ID, PROJECT_NAME, PARTIAL_DEPLOYMENTS, 
DEPLOY_PRIORITY, PROJECT_TYPE, FULL_PATH) AS 
select p.PROJECT_ID, p.FOLDER_ID, p.PROJECT_NAME, p.PARTIAL_DEPLOYMENTS, p.DEPLOY_PRIORITY, p.PROJECT_TYPE, fp.full_path
from FD.PROJECT P, 
(with recursive folders (project_id, folder_id, parent_folder_id, folder_name, lvl) as (
  select p.project_id, f.folder_id, f.parent_folder_id, f.folder_name, 0 lvl
  from FD.FOLDER f, FD.PROJECT p
  where f.folder_id = p.folder_id and p.IS_ACTIVE='Y'
  union all
  select p2. project_id, f2.folder_id, f2.parent_folder_id, f2.folder_name, f3.lvl + 1
  from folders f3, fd.folder f2, fd.project p2
  where f3.parent_folder_id = f2.folder_id and p2.project_id = f3.project_id)
select folders.project_id, string_agg(folders.folder_name, '/' order by lvl desc) as full_path from folders
group by folders.project_id) fp where p.IS_ACTIVE='Y' and p.project_id = fp.project_id;

CREATE OR REPLACE VIEW FD.VFOLDERHIERARCHY (FOLDER_ID,
PARENT_FOLDER_ID, FOLDER_NAME, DESCRIPTION, IS_APPLICATION, IS_ACTIVE
, CREATED_ON, CREATED_BY, UPDATED_ON, UPDATED_BY, VERSION_NUMBER,
START_FOLDER_ID) AS
WITH
  recursive FOLDERS (folder_id,parent_folder_id,folder_name,description,
  is_application,is_active,created_on,created_by,updated_on,updated_by,
  version_number,start_folder_id) AS
  (
    SELECT
      f.FOLDER_ID        AS folder_id,
      f.PARENT_FOLDER_ID AS parent_folder_id,
      f.FOLDER_NAME      AS folder_name,
      f.DESCRIPTION      AS description,
      f.IS_APPLICATION   AS is_application,
      f.IS_ACTIVE        AS is_active,
      f.CREATED_ON       AS created_on,
      f.CREATED_BY       AS created_by,
      f.UPDATED_ON       AS updated_on,
      f.UPDATED_BY       AS updated_by,
      f.VERSION_NUMBER   AS version_number,
      f.FOLDER_ID        AS start_folder_id
    FROM
      FD.FOLDER f
    UNION ALL
    SELECT
      f2.FOLDER_ID        AS folder_id,
      f2.PARENT_FOLDER_ID AS parent_folder_id,
      f2.FOLDER_NAME      AS folder_name,
      f2.DESCRIPTION      AS description,
      f2.IS_APPLICATION   AS is_application,
      f2.IS_ACTIVE        AS is_active,
      f2.CREATED_ON       AS created_on,
      f2.CREATED_BY       AS created_by,
      f2.UPDATED_ON       AS updated_on,
      f2.UPDATED_BY       AS updated_by,
      f2.VERSION_NUMBER   AS version_number,
      f3.start_folder_id  AS start_folder_id
    FROM
      FOLDERS f3
    JOIN FD.FOLDER f2 on f3.parent_folder_id = f2.FOLDER_ID
)
SELECT
  FOLDERS.folder_id        AS folder_id,
  FOLDERS.parent_folder_id AS parent_folder_id,
  FOLDERS.folder_name      AS folder_name,
  FOLDERS.description      AS description,
  FOLDERS.is_application   AS is_application,
  FOLDERS.is_active        AS is_active,
  FOLDERS.created_on       AS created_on,
  FOLDERS.created_by       AS created_by,
  FOLDERS.updated_on       AS updated_on,
  FOLDERS.updated_by       AS updated_by,
FOLDERS.version_number   AS version_number,
  FOLDERS.start_folder_id  AS start_folder_id
FROM
  FOLDERS;

CREATE OR REPLACE VIEW FD.VRPTENVDTSRCH AS
SELECT  
  WE.WORKFLOW_EXECUTION_ID,  
  P.PROJECT_ID,  
  P.FOLDER_ID,  
  P.PROJECT_NAME,  
  PV.PROJECT_VERSION_NAME,  
  PV.SCM_REVISION SCM_REVISION,  
  NULL PO_SCM_REVISION,  
  W.WORKFLOW_TYPE,  
  W.WORKFLOW_ID,  
  WV.WORKFLOW_VERSION,  
  E.ENVIRONMENT_NAME,  
  WE.ENVIRONMENT_ID,  
  I.INSTANCE_NAME,  
  WE.INSTANCE_ID,  
  WE.EXECUTION_STATUS,  
  WR.CREATED_ON REQUESTED_ON,  
  WR.CREATED_BY REQUESTED_BY,  
  WE.START_TIME,  
  WE.END_TIME,  
  WR.FLEX_FIELD_1,  
  WR.FLEX_FIELD_2,  
  WR.FLEX_FIELD_3,  
  WR.FLEX_FIELD_4,  
  WR.FLEX_FIELD_5,  
  WR.FLEX_FIELD_6,  
  WR.FLEX_FIELD_7,  
  WR.FLEX_FIELD_8,  
  WR.FLEX_FIELD_9,  
  WR.FLEX_FIELD_10,  
  PV.FLEX_FIELD_1 BUILD_FLEX_FIELD1,  
  PV.FLEX_FIELD_2 BUILD_FLEX_FIELD2,  
  PV.FLEX_FIELD_3 BUILD_FLEX_FIELD3,  
  PV.FLEX_FIELD_4 BUILD_FLEX_FIELD4,  
  PV.FLEX_FIELD_5 BUILD_FLEX_FIELD5,  
  PV.FLEX_FIELD_6 BUILD_FLEX_FIELD6,  
  PV.FLEX_FIELD_7 BUILD_FLEX_FIELD7,  
  PV.FLEX_FIELD_8 BUILD_FLEX_FIELD8,  
  PV.FLEX_FIELD_9 BUILD_FLEX_FIELD9,  
  PV.FLEX_FIELD_10 BUILD_FLEX_FIELD10,  
  PV.PACKAGE_NAME,  
  NULL SEQUENCE_NUMBER,
  NULL OBJECT_PATH,  
  P.PARTIAL_DEPLOYMENTS,  
  PV.ALL_FILES_REQUESTED,  
  WR.REL_DEFINITION_ID,  
  WR.REL_SNAPSHOT_ID,  
  RD.REL_NAME,     
  RS.REL_SNAPSHOT,   
  WR.PIPELINE_STAGE_EXEC_ID as STAGE_EXEC_ID,  
  WR.WORKFLOW_REQUEST_ID,    
  NULL PKG_STATUS, 
  (SELECT string_agg(WI.WORK_ITEM_NUMBER, ', ' ORDER BY WI.WORK_ITEM_NUMBER)  
   FROM FD.PROJECT_VERSION_WORK_ITEM PVWI, FD.WORK_ITEM WI WHERE WI.WORK_ITEM_ID = PVWI.WORK_ITEM_ID AND PVWI.PROJECT_VERSION_ID = PV.PROJECT_VERSION_ID) as ITS_TICKET_IDS,  
  (SELECT string_agg(TICKET.TICKET_NUMBER, ', ' ORDER BY TICKET.TICKET_NUMBER) FROM FD.WORKFLOW_REQUEST_TICKET WRT, FD.CMS_TICKET TICKET WHERE WRT.CMS_TICKET_ID=TICKET.CMS_TICKET_ID AND WRT.WORKFLOW_REQUEST_ID=WR.WORKFLOW_REQUEST_ID) CMS_TICKET_IDS,
  PS.STREAM_NAME  
FROM   
  FD.WORKFLOW_EXECUTION WE,  
  FD.PROJECT P,  
  FD.PROJECT_VERSION PV
  left outer join FD.PROJECT_STREAM PS on PS.PROJECT_STREAM_ID = PV.PROJECT_STREAM_ID,  
  FD.PROJECT_WORKFLOW PW,  
  FD.ENVIRONMENT E,  
  FD.INSTANCE I,  
  FD.WORKFLOW_VERSION WV,  
  FD.WORKFLOW W,  
  FD.WORKFLOW_REQUEST WR
  left outer join FD.REL_DEFINITION RD on WR.REL_DEFINITION_ID = RD.REL_DEFINITION_ID 
  left outer join FD.REL_SNAPSHOT RS  on WR.REL_SNAPSHOT_ID = RS.REL_SNAPSHOT_ID  
WHERE P.PROJECT_ID = WE.PROJECT_ID  
AND PW.PROJECT_WORKFLOW_ID = WE.PROJECT_WORKFLOW_ID  
AND E.ENVIRONMENT_ID = WE.ENVIRONMENT_ID  
AND I.INSTANCE_ID = WE.INSTANCE_ID  
AND PV.PROJECT_VERSION_ID = WE.PROJECT_VERSION_ID  
AND WV.WORKFLOW_VERSION_ID = WE.WORKFLOW_VERSION_ID  
AND W.WORKFLOW_ID = PW.WORKFLOW_ID  
AND WR.WORKFLOW_REQUEST_ID = WE.WORKFLOW_REQUEST_ID  
AND WE.PARENT_WORKFLOW_EXECUTION_ID IS NULL;

CREATE OR REPLACE VIEW FD.VRPTENVPROJSTAT as
SELECT we.workflow_execution_id,
    p.folder_id,
    p.project_id,
    p.project_name,
    pv.project_version_name,
    pv.scm_revision,
    w.workflow_type,
    w.workflow_id,
    w.workflow_name,
    wv.workflow_version,
    pv.all_files_requested,
    e.environment_id,
    e.environment_name,
    i.instance_id,
    i.instance_name,
    we.execution_status,
    pw.project_workflow_type,
    we.start_time,
    we.end_time,
    wr.created_by AS requested_by,
    wr.created_on AS requested_on,
    wr.flex_field_1,
    wr.flex_field_2,
    wr.flex_field_3,
    wr.flex_field_4,
    wr.flex_field_5,
    wr.flex_field_6,
    wr.flex_field_7,
    wr.flex_field_8,
    wr.flex_field_9,
    wr.flex_field_10,
    pv.flex_field_1 AS build_flex_field1,
    pv.flex_field_2 AS build_flex_field2,
    pv.flex_field_3 AS build_flex_field3,
    pv.flex_field_4 AS build_flex_field4,
    pv.flex_field_5 AS build_flex_field5,
    pv.flex_field_6 AS build_flex_field6,
    pv.flex_field_7 AS build_flex_field7,
    pv.flex_field_8 AS build_flex_field8,
    pv.flex_field_9 AS build_flex_field9,
    pv.flex_field_10 AS build_flex_field10,
    NULL AS package_name,
    NULL AS package_created_by,
    NULL AS package_created_on,
    NULL AS package_updated_by,
    NULL AS package_updated_on,
    '' AS object_path,
    '' AS object_type,
    '' AS sub_component_name,
    '' AS sub_component_type,
    p.partial_deployments,
    f.folder_name,
    wr.rel_definition_id,
    wr.rel_snapshot_id,
    rd.rel_name,
    rd.rel_status,
    pd.name AS pipeline_name,
    rs.rel_snapshot,
    rs.created_by AS snapshot_submitted_by,
    wr.workflow_request_id,
    wr.pipeline_stage_exec_id,
    ( SELECT string_agg(wi.work_item_number, ', ' ORDER BY (wi.work_item_number)) AS string_agg
           FROM fd.workflow_execution_work_item exe_wi,
            fd.work_item wi
          WHERE exe_wi.workflow_execution_id = we.workflow_execution_id AND wi.work_item_id = exe_wi.work_item_id) AS work_item_ids,
    ( SELECT string_agg(ticket.ticket_number, ', ' ORDER BY (ticket.ticket_number)) AS string_agg
           FROM fd.workflow_request_ticket wrt,
            fd.cms_ticket ticket
          WHERE wrt.cms_ticket_id = ticket.cms_ticket_id AND wrt.workflow_request_id = wr.workflow_request_id) AS external_ticket,
    pv.project_version_id,
    ( SELECT string_agg(ht.action_by, ', ' ORDER BY (ht.action_by)) AS string_agg
           FROM fd.human_task ht
          WHERE (ht.workflow_request_id = wr.workflow_request_id OR ht.pipeline_stage_exec_id = wr.pipeline_stage_exec_id AND ht.pipeline_stage_gate_id IS NOT NULL OR ht.workflow_execution_id = we.predeploy_workflow_exec_id) AND ht.task_status = 'APPROVED' AND (ht.task_type in ('PRE_DEPLOY_REVIEW', 'APPROVAL'))) AS approved_by_usernames,
    ps.stream_name,
    wr.force_deploy AS force,
    wr.folder_request_id,
    NULL AS pkg_status,
    NULL AS commit_user
   FROM fd.project_wf_current_status pwcs
   join fd.project p
      on p.project_id = pwcs.project_id
     and p.partial_deployments = 'N'
   join fd.workflow_execution we on we.workflow_execution_id = pwcs.workflow_execution_id
    join fd.project_version pv on pv.project_version_id = we.project_version_id
    join fd.environment e on e.environment_id = pwcs.environment_id
    join fd.project_workflow pw
        on pw.project_workflow_id = we.project_workflow_id
       AND pw.project_workflow_type IN ('DEPLOY', 'SYNCSTATE')
    join fd.instance i on i.instance_id = pwcs.instance_id 
    join fd.workflow_request wr on wr.workflow_request_id = we.workflow_request_id
    Join fd.folder f on p.folder_id = f.folder_id
    join fd.workflow_version wv on wv.workflow_version_id = we.workflow_version_id
    join fd.workflow w on w.workflow_id = we.workflow_id
    LEFT JOIN fd.rel_definition rd ON wr.rel_definition_id = rd.rel_definition_id
    LEFT JOIN fd.pipeline_definition pd ON rd.pipeline_definition_id = pd.pipeline_definition_id
    LEFT JOIN fd.rel_snapshot rs ON wr.rel_snapshot_id = rs.rel_snapshot_id
    LEFT JOIN fd.project_stream ps ON pv.project_stream_id = ps.project_stream_id
UNION ALL
 SELECT we.workflow_execution_id,
    p.folder_id,
    p.project_id,
    p.project_name,
    pv.project_version_name,
    pkgobj.scm_revision,
    w.workflow_type,
    w.workflow_id,
    w.workflow_name,
    wv.workflow_version,
    pv.all_files_requested,
    e.environment_id,
    e.environment_name,
    i.instance_id,
    i.instance_name,
    we.execution_status,
    pw.project_workflow_type,
    we.start_time,
    we.end_time,
    wr.created_by AS requested_by,
    wr.created_on AS requested_on,
    wr.flex_field_1,
    wr.flex_field_2,
    wr.flex_field_3,
    wr.flex_field_4,
    wr.flex_field_5,
    wr.flex_field_6,
    wr.flex_field_7,
    wr.flex_field_8,
    wr.flex_field_9,
    wr.flex_field_10,
    pv.flex_field_1 AS build_flex_field1,
    pv.flex_field_2 AS build_flex_field2,
    pv.flex_field_3 AS build_flex_field3,
    pv.flex_field_4 AS build_flex_field4,
    pv.flex_field_5 AS build_flex_field5,
    pv.flex_field_6 AS build_flex_field6,
    pv.flex_field_7 AS build_flex_field7,
    pv.flex_field_8 AS build_flex_field8,
    pv.flex_field_9 AS build_flex_field9,
    pv.flex_field_10 AS build_flex_field10,
    pv.package_name,
    pp.created_by AS package_created_by,
    pp.created_on AS package_created_on,
    pp.updated_by AS package_updated_by,
    pp.updated_on AS package_updated_on,
    prjobj.object_path,
    objtyp.object_type_code AS object_type,
    prjobj.sub_component_name,
    prjobj.sub_component_type,
    p.partial_deployments,
    f.folder_name,
    wr.rel_definition_id,
    wr.rel_snapshot_id,
    rd.rel_name,
    rd.rel_status,
    pd.name AS pipeline_name,
    rs.rel_snapshot,
    rs.created_by AS snapshot_submitted_by,
    wr.workflow_request_id,
    wr.pipeline_stage_exec_id,
    ( SELECT string_agg(wi.work_item_number, ', ' ORDER BY (wi.work_item_number)) AS string_agg
           FROM fd.workflow_execution_work_item exe_wi,
            fd.work_item wi
          WHERE exe_wi.workflow_execution_id = we.workflow_execution_id AND wi.work_item_id = exe_wi.work_item_id) AS work_item_ids,
    ( SELECT string_agg(ticket.ticket_number, ', ' ORDER BY (ticket.ticket_number)) AS string_agg
           FROM fd.workflow_request_ticket wrt,
            fd.cms_ticket ticket
          WHERE wrt.cms_ticket_id = ticket.cms_ticket_id AND wrt.workflow_request_id = wr.workflow_request_id) AS external_ticket,
    pv.project_version_id,
    ( SELECT string_agg(ht.action_by, ', ' ORDER BY (ht.action_by)) AS string_agg
           FROM fd.human_task ht
          WHERE (ht.workflow_request_id = wr.workflow_request_id OR ht.pipeline_stage_exec_id = wr.pipeline_stage_exec_id AND ht.pipeline_stage_gate_id IS NOT NULL OR ht.workflow_execution_id = we.predeploy_workflow_exec_id) AND ht.task_status = 'APPROVED' AND ht.task_type in ('PRE_DEPLOY_REVIEW', 'APPROVAL')) AS approved_by_usernames,
    ps.stream_name,
    wr.force_deploy AS force,
    wr.folder_request_id,
    ( SELECT string_agg(pkgexec.execution_status, ',' ORDER BY (pkgexec.execution_status)) AS string_agg
           FROM fd.plugin_execution pexec,
            fd.package_object_execution pkgexec
          WHERE pkgobj.package_object_id IS NOT NULL 
          AND pkgexec.package_object_id = pkgobj.package_object_id
          AND pkgexec.plugin_execution_id = pexec.plugin_execution_id
          AND pexec.workflow_execution_id = pkjobjcs.workflow_execution_id
          AND w.workflow_type in ('DEPLOY', 'SYNCSTATE')) AS pkg_status,
    por.commit_user
   FROM fd.package_obj_current_status pkjobjcs
    join fd.workflow_execution we on we.workflow_execution_id = pkjobjcs.workflow_execution_id
    join fd.project p 
       on p.project_id = we.project_id 
      AND p.partial_deployments = 'Y'
    join fd.folder f on p.folder_id = f.folder_id
    join fd.project_version pv
	  on pv.project_version_id = we.project_version_id
	  and p.project_id = pv.project_id
    join fd.environment e on e.environment_id = we.environment_id
    join fd.instance i on i.instance_id = we.instance_id
    join fd.project_workflow pw 
      on pw.project_workflow_id = we.project_workflow_id 
     and pw.project_workflow_type in ('DEPLOY', 'SYNCSTATE')
    join fd.workflow_request wr on wr.workflow_request_id = we.workflow_request_id
    join fd.package_object pkgobj
      on pkgobj.project_object_id = pkjobjcs.project_object_id
     AND pv.project_version_id = pkgobj.project_version_id
    join fd.project_object prjobj on pkgobj.project_object_id = prjobj.project_object_id
    join fd.object_type objtyp on prjobj.object_type_id = objtyp.object_type_id
    join fd.workflow_version wv on wv.workflow_version_id = we.workflow_version_id
    join fd.workflow w on w.workflow_id = we.workflow_id
     LEFT JOIN fd.project_package pp
            ON pv.project_id = pp.project_id
	       AND pv.package_name = pp.package_name
     LEFT JOIN fd.project_stream ps ON ps.project_stream_id = pv.project_stream_id
     LEFT JOIN fd.rel_definition rd ON wr.rel_definition_id = rd.rel_definition_id
     LEFT JOIN fd.pipeline_definition pd ON rd.pipeline_definition_id = pd.pipeline_definition_id
     LEFT JOIN fd.rel_snapshot rs ON wr.rel_snapshot_id = rs.rel_snapshot_id
     LEFT JOIN fd.project_object_revision por
	       ON por.project_object_id = pkgobj.project_object_id
	      AND por.scm_revision = pkgobj.scm_revision;
--FLEXDEPLOY-14221

CREATE OR REPLACE VIEW FD.VINTGINSTPROPERTYSET
AS  
    SELECT  PS.PROPERTY_SET_ID, PS.PROPERTY_SET_NAME, PS.OWNER_TYPE, SPLIT_PART(PS.PROPERTY_SET_NAME, '_', 1) AS OWNER_SUB_TYPE
        FROM FD.PROPERTY_SET PS WHERE PS.OWNER_TYPE='SCM'
    UNION
    SELECT  PS.PROPERTY_SET_ID, PS.PROPERTY_SET_NAME, PS.OWNER_TYPE, ITS.NAME AS OWNER_SUB_TYPE
        FROM FD.PROPERTY_SET PS 
        JOIN FD.ISSUETRACKINGSYSTEM ITS ON PS.OWNER_ID = ITS.ISSUETRACKINGSYSTEMID
        WHERE PS.OWNER_TYPE='ITS'
    UNION
    SELECT PS.PROPERTY_SET_ID, PS.PROPERTY_SET_NAME, PS.OWNER_TYPE, CMS.NAME AS OWNER_SUB_TYPE
        FROM FD.PROPERTY_SET PS 
        JOIN FD.CMS CMS ON PS.OWNER_ID = CMS.CMS_ID 
        WHERE PS.OWNER_TYPE='CMS'
    UNION
    SELECT PS.PROPERTY_SET_ID, PS.PROPERTY_SET_NAME, PS.OWNER_TYPE, TT.TESTING_TOOL_NAME AS OWNER_SUB_TYPE
        FROM FD.PROPERTY_SET PS 
        JOIN FD.TESTING_TOOL TT ON PS.OWNER_ID = TT.TESTING_TOOL_ID
        WHERE PS.OWNER_TYPE='TESTING_TOOL'
    UNION
    SELECT PS.PROPERTY_SET_ID, PS.PROPERTY_SET_NAME, PS.OWNER_TYPE, AP.NAME AS OWNER_SUB_TYPE
        FROM FD.PROPERTY_SET PS 
        JOIN FD.ACCOUNT_PROVIDER AP ON PS.OWNER_ID = AP.ACCOUNT_PROVIDER_ID
        WHERE PS.OWNER_TYPE = AP.TYPE;
        
CREATE OR REPLACE VIEW FD.VDAILYWEBHOOKMESSAGES
AS select
      count(case STATUS when 'FAILED' then 1 else null end) as FAILED,       
      count(case STATUS when 'SUCCESS' then 1 else null end) as SUCCESS,      
      count(*) as TOTAL, 
      date(CREATED_ON) as CREATED_DAY
from FD.WEBHOOK_MESSAGE   
  where CREATED_ON > current_date - 7 
  group by date(CREATED_ON) order by CREATED_DAY;

CREATE OR REPLACE VIEW FD.VTAGASSIGNMENTS AS
SELECT 
  OBJECT_ID,
  OBJECT_TYPE,
  '||'||STRING_AGG(TA.TAG_KEY, '||' ORDER BY TA.TAG_KEY)||'||' TAGS,
  '||'||STRING_AGG(CAST(TA.TAG_ID AS VARCHAR(16)), '||' ORDER BY TA.TAG_KEY)||'||' TAG_IDS,
  '||'||STRING_AGG(CAST(TA.TAG_ASSIGNMENT_ID AS VARCHAR(16)), '||' ORDER BY TA.TAG_KEY)||'||' TAG_ASSIGNMENT_IDS
FROM
  (SELECT TA.TAG_ASSIGNMENT_ID,
    TA.TAG_ID,
    T.TAG_KEY,
    TA.OBJECT_ID,
    TA.OBJECT_TYPE
  FROM FD.TAG T,
    FD.TAG_ASSIGNMENT TA
  WHERE TA.TAG_ID = T.TAG_ID
  ) TA
GROUP BY OBJECT_ID,
  OBJECT_TYPE;
  
CREATE OR REPLACE VIEW fd.VOBJECTPERMISSION AS
    SELECT
        ug.user_id,
        p.object_id,
        p.object_type,
        p.action_type
    FROM
        fd.fd_user_group ug
        INNER JOIN fd.fd_group_permission gp ON ug.group_id = gp.group_id
        INNER JOIN fd.fd_permission       p ON gp.permission_id = p.permission_id
        where (p.for_object_type is null or p.for_object_type='FOLDER' or p.action_type = 'CREATESNAPSHOT')
    UNION
    SELECT
        ug.user_id,
        p.object_id,
        p.object_type,
        p.action_type
    FROM
        fd.fd_user_ext_group ug
        INNER JOIN fd.fd_group_permission gp ON ug.group_id = gp.group_id
        INNER JOIN fd.fd_permission       p ON gp.permission_id = p.permission_id
        where (p.for_object_type is null or p.for_object_type='FOLDER' or p.action_type = 'CREATESNAPSHOT');
